import {loadState,saveState} from './../components/localStorage';
import {store} from 'redux';
import {REQUEST_MENU,REQUEST_SUBITEM,SELECT_SUBMENU,SELECTED_MENU_CLICK,RECIEVE_FETCHSUBITEM,RECIEVE_FETCHMENU,CHECK_PRODUCT_STATUS,RECIEVE_SEARCH,SEARCHREQUESTSTART,SEARCH_LOCALLY,INITIALSTATE,SAVESTATE} from '../actions/actions';


export const listofSubitem =(state={isListFetching:false,Listitems:[]},action)=>
	{
		switch(action.type)
		{
				case REQUEST_SUBITEM:
			return Object.assign({},state,{
				isListFetching:true
			});
					   
				case RECIEVE_FETCHSUBITEM:		 return Object.assign({},state,{
		isListFetching:false,
		Listitems:action.itemList,
	}) ;
	default: return state;	   
		}
		
	}

export const fetchsubitemReducer=(state={},action)=>
	{
		switch(action.type)
		{ 
			case REQUEST_SUBITEM:			
			case RECIEVE_FETCHSUBITEM:
		return Object.assign({},state,{
			[action.subcategoryItem]:listofSubitem(state[action.subcategoryItem],action),
			subcategoryItem:action.subcategoryItem
		});
			default: return state;
		}
	}





export const searchDataSource=(state={isSearchFetching:false,dataSource:[],dataSourceLocally:[]},action)=>{
switch(action.type)
{
	case SEARCHREQUESTSTART:
	return Object.assign({},state,{
isSearchFetching:true
	});


	case RECIEVE_SEARCH://console.log("Inside Reducer searchDataSource"+action.dataSourceAction);
	return Object.assign({},state,{isSearchFetching:false,
				dataSource:action.dataSourceAction

			});
case SEARCH_LOCALLY:
return Object.assign({},state,{
	isSearchFetching:false,
	dataSourceLocally:[ 'Apple', 'Apricot', 'Avocado',
  'Banana', 'Bilberry', 'Blackberry', 'Blackcurrant', 'Blueberry',
  'Boysenberry', 'Blood Orange',
  'Cantaloupe', 'Currant', 'Cherry', 'Cherimoya', 'Cloudberry',
  'Coconut', 'Cranberry', 'Clementine',
  'Damson', 'Date', 'Dragonfruit', 'Durian',
  'Elderberry',
  'Feijoa', 'Fig',
  'Goji berry', 'Gooseberry', 'Grape', 'Grapefruit', 'Guava',
  'Honeydew', 'Huckleberry',
  'Jabouticaba', 'Jackfruit', 'Jambul', 'Jujube', 'Juniper berry',
  'Kiwi fruit', 'Kumquat',
  'Lemon', 'Lime', 'Loquat', 'Lychee',
  'Nectarine',
  'Mango', 'Marion berry', 'Melon', 'Miracle fruit', 'Mulberry', 'Mandarine',
  'Olive', 'Orange',
  'Papaya', 'Passionfruit', 'Peach', 'Pear', 'Persimmon', 'Physalis', 'Plum', 'Pineapple',
  'Pumpkin', 'Pomegranate', 'Pomelo', 'Purple Mangosteen',
  'Quince',
  'Raspberry', 'Raisin', 'Rambutan', 'Redcurrant',
  'Salal berry', 'Satsuma', 'Star fruit', 'Strawberry', 'Squash', 'Salmonberry',
  'Tamarillo', 'Tamarind', 'Tomato', 'Tangerine',
  'Ugli fruit',
  'Watermelon']
});
	default:return state;
}

}







export const fetchmenuReducer=(state={isFetching:false,years:[],submenu:[],
items:[]},action)=>
	{var data = [];
var obj;
	switch(action.type){
		case REQUEST_MENU:
		return Object.assign({},state,{
			isFetching:true
		});
		
		case SELECT_SUBMENU:
	for (var i= 0;i<state.years.length;i=i+1)
{ for(var propName in state.years[i])
	{
		if(propName==action.submenu){
		
                for(var j=0;j<state.years[i][propName].subCategories.length;j=j+1){
	
	              	obj={};
	             	obj['name']=state.years[i][propName].subCategories[j];
                   data.push(obj);
                   }		

	}
	}

}		
		
		return Object.assign({},state,{
			isFetching:false,
			submenu:data,
			parentMenu:action.submenu		
		});		
		
case SELECTED_MENU_CLICK:
var selectedcategoryName="Not Found";
			for (var i= 0;i<state.years.length;i=i+1)
{ for(var propName in state.years[i])
	{ 	if(propName==action.selectedmenuonClick){
		selectedcategoryName=action.selectedmenuonClick;
		console.log("Inside reducers",selectedcategoryName);
                for(var j=0;j<state.years[i][propName].subCategories.length;j=j+1){
	
	              	obj={};
	             	obj['name']=state.years[i][propName].subCategories[j];
                   data.push(obj);
                   }		

	}
	
	}

}
console.log("Inside reducers" + selectedcategoryName);	

		return Object.assign({},state,{
			isFetching:false,
			selectedmenuonclick:data,
           selectedcategoryName:selectedcategoryName		
		});	

		case CHECK_PRODUCT_STATUS: 
		return Object.assign({},state,{ 
			cartDetails:(action.cartDetails=="Use Previous cart State" ? state.cartDetails:action.cartDetails),
			status:action.status
		});
		
		
		case RECIEVE_FETCHMENU:
		console.log(action.specialOffers);
		
		for (var i= 0;i<action.values.length;i=i+1)
{for(var propName in action.values[i])
	{if(propName=="name"){
		obj={};
		obj[action.values[i][propName]]=action.values[i];
         data.push(obj);
	}
	}

}
		return Object.assign({},state,{
			isFetching:false,
			years:data,
			items:action.dataformenus,
			specialOffers:action.specialOffers	,
			cartDetails:action.cartDetails,
			userId:action.userId
		});
		default:return state;
	}	
		
	}







export const intialReducer=(state={saveState:undefined},action)=>{

switch(action.type)
{
	case INITIALSTATE:return  Object.assign({},state,{saveState:action.userName===loadState() ? loadState():undefined})

	case SAVESTATE: console.log(action.json);
					console.log("Saving State",saveState(action.json));
					return Object.assign({},state,{saveState:saveState(action.json)})
					

	default: return state;	   
}


}
