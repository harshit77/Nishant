import React from 'react';

export default class Flexisel extends React.Component{
	constructor(props){
		super(props);
	}
render()
{
	return (
	<div className="container ">      
		<div className="row flexisel-container">

			<div className="twelve columns">	
				
			  <div className="carouselHeading">
 <span>Jhakhas</span></div>
				<ul id="flexiselDemo2"> 
					<li><img src="http://9bitstudios.github.io/flexisel/images/logo-adidas.png" /></li>  	
					<li><img src="http://9bitstudios.github.io/flexisel/images/logo-nike.png" /></li> 
					<li><img src="http://9bitstudios.github.io/flexisel/images/logo-amazon.png" /></li> 
					<li><img src="http://9bitstudios.github.io/flexisel/images/logo-spotify.png" /></li> 
					<li><img src="http://9bitstudios.github.io/flexisel/images/logo-android.png" /></li> 					 						    	  	       	   	    	
				</ul>
				<div className="clearout"></div>
			
			</div>
		
		</div>			
		
		
		

	</div>
	  
	
	
	
	)
	
	
}	
	
}