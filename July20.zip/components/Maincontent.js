import React from 'react';
import {Tabs,Tab} from 'material-ui/Tabs';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import CircularProgress from 'material-ui/CircularProgress';
import { Link } from 'react-router';
import FlatButton from 'material-ui/FlatButton';import {connect} from 'react-redux';
import {selected_menu_click,fetchsubitem,recieve_product_status} from '../actions/actions';
class Maincontent extends React.Component{

	constructor(props){
		super(props);
}


componentDidMount(){
console.log("Lets see",this.props.params.id);
let contentid=this.props.params.id===undefined ? "Grocery & Staples":this.props.params.id;
	console.log("Inside MainContent"+ contentid);
	this.props.dispatch(selected_menu_click(contentid));
}	
	
	
render(){
const {isListFetching,selectedmenuonclick,selectedcategoryName,Listitems,lastadded}=this.props;{/* missing layoutType*/}
console.log(selectedmenuonclick);
	return(
	 <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
		  <div className="selectedcategorytitle">{selectedcategoryName}CDC</div>
		  </div>





		  {isListFetching && <div className="row features-loader"><div className="alingCenter"><CircularProgress size={80} thickness={7} /></div></div>}
		
		{!isListFetching &&  <div className="row features-grid">
		  {typeof selectedmenuonclick !="undefined" && selectedmenuonclick.map((element,i)=>{
			  return (
		<div className="feature-tile" key={i}>
           <div className="feature-icon" >
       
        </div>
    <div>
	     <Link to={`/product/${selectedcategoryName}/${element.name.name}`}> <h6 className="feature-title">{element.name.name}</h6></Link><p className="feature-description" >
		 {typeof element.name.products !="undefined" && element.name.products.map((secondText,i)=>{
			return ( <span key={i}>{secondText.name}</span>)
		})
		 }
	       </p>
	</div>
</div> 
			  )
		  })} {/* End of Layout 1 */}
		
	
</div>
}

{/* End of MainContent */}

</div> 

	)
}	
	
}

const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer,fetchsubitemReducer}=state;
const {selectedcategoryName,selectedmenuonclick}=fetchmenuReducer;
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
console.log("mapStateToProps in Maincontent "+selectedmenuonclick);
return {selectedmenuonclick,isListFetching,Listitems,selectedcategoryName};

}


export default connect(mapStateToProps)(Maincontent);