import React from 'react';
import {Tabs, Tab} from 'material-ui/Tabs';
import FontIcon from 'material-ui/FontIcon';
import MapsPersonPin from 'material-ui/svg-icons/maps/person-pin';
import SocialPersonAdd from 'material-ui/svg-icons/social/person-add';
import LoginRegisterForm from './LoginRegisterForm';





export default class TabsControlled extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      value:'sectionA',
    };
    this.handleChange=this.handleChange.bind(this);
  }

  handleChange(value){
    this.setState({
      value: value,
    });
  };

  render() {
    return (
      <Tabs
        value={this.state.value}
        onChange={this.handleChange}
        inkBarStyle={{backgroundColor:'#012b72'}}
      >
        <Tab  icon={<MapsPersonPin/>} label="Login" value="sectionA">
          <div>
            {this.state.value==="sectionA" ? <LoginRegisterForm/>:null}
          </div>
        </Tab>
        <Tab icon={<SocialPersonAdd/>} label="SignUp" value="sectionB">
          <div>
            <h2 >Controllable Tab B</h2>
            <p>
              This is another example of a controllable tab. Remember, if you
              use controllable Tabs, you need to give all of your tabs values or else
              you wont be able to select them.
            </p>
          </div>
        </Tab>
      </Tabs>
    );
  }
}