    {/*<!-- Wrapper for slides -->*/} 
    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
      	  
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
         	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
           	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
	<!-- End Carousel --> */} 








 {/*<!-- pRODUCT lISTiTEM -->*/}   


    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
        {/*<!-- Wrapper for slides -->*/}   
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
          {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
            {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
  {/*<!-- End Carousel --> */} 
