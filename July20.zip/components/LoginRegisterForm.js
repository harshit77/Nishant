import React from 'react';
import {Field,reduxForm} from 'redux-form';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem'
import SelectField from 'material-ui/SelectField'
import {intialState} from './../actions/actions';
import {connect} from 'react-redux';
import Submit from './Submit';
import RaisedButton from 'material-ui/RaisedButton';
import Divider from 'material-ui/Divider';
import Subheader from 'material-ui/Subheader';


const validate=values=>{
	const errors={};
	const requiredFields=['username','password'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })



 if (
    values.username &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.username) && !/^[7-9]{1}[0-9]{9}$/i.test(values.username))
  ) {
    errors.username = isNaN(values.username)===true ?'Invalid email address' :"Invalid Mobile Number";
  }
	 return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
	return (
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
		)

}


class LoginRegisterForm extends React.Component
{
	constructor(props)
	{
		super(props)
	}
	componentDidMount()
	{
		this.props.dispatch(intialState(this.props.userId));
	}

	render()
	{
		const {error,handleSubmit,pristine,invalid,reset,submitting,saveState}=this.props;
		return(<div style={{textAlign:'center'}}>
			
				<form onSubmit={handleSubmit(Submit)}>
				<div>
				{saveState!=undefined 
					&& saveState.username}
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
					<div>
					<Field name="username" component={renderTextField} label="Mobile Number or Email id" type="text"/>
					</div>
					
					<div>
						<Field name="password" component={renderTextField} label="Password" type="password"/>
					</div>
				
					<div>
					<RaisedButton
          label="Login"          
          primary={true} style={{margin:'20px 0'}}
          disabled={invalid || pristine || submitting}
		       type="submit"    
        />
					 </div>
				</form>

					<Divider style={{marginTop:10,marginBottom:10}}/>
				<div style={{marginTop:25}} >
				 <RaisedButton
          label="Facebook"          
          primary={true} 
		           
        />
				<RaisedButton label="Google" labelColor="#fff" style={{marginLeft:20}} backgroundColor="rgb(38, 166, 154)" />
 				 </div>

				</div>
				




			  )
	}

}

LoginRegisterForm=reduxForm({
	form:'loginRegisterform',
	validate
})(LoginRegisterForm);

const mapStateToProps=(state)=>{
 const {intialReducer,fetchmenuReducer}=state;
 const {saveState}=intialReducer;
 const {userId}=fetchmenuReducer;
console.log("Inside mapStateToProps");
 return {saveState,userId};

}





export default connect(mapStateToProps)(LoginRegisterForm);