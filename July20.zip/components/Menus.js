import React from 'react';
import {List,ListItem} from 'material-ui/List';
import Paper from 'material-ui/Paper';
import {connect} from 'react-redux';
import Subheader from 'material-ui/Subheader';
import Maincontent from './Maincontent';
import CircularProgress from 'material-ui/CircularProgress';
import { Link } from 'react-router';
import {select_submenu,selected_menu_click,fetchsubitem,fetchmenus,recieve_product_status} from '../actions/actions';
const subHeaderStyle={color:"#00B9F5",
    fontWeight: 600,
    fontSize: 16};
class Menus extends React.Component{
	constructor(props){
		super(props);
		this.state={hover:false};
		this.toogleHover=this.toogleHover.bind(this);
		this.toogleSubDataHover=this.toogleSubDataHover.bind(this);
		this.handleClick=this.handleClick.bind(this);
		this.handleSubcategory=this.handleSubcategory.bind(this);
		
	}
	
	toogleHover(){
		this.setState({hover:!this.state.hover});
		
	}
	toogleSubDataHover(item,event){
		
		this.props.dispatch(select_submenu(item));
	}
	handleClick(item,event)
	{console.log("Clicked",item);
 //$('html, body').animate({
   //     scrollTop: $(".features-grid").offset().top-60
    //}, 2000);
	this.setState({hover:!this.state.hover});
 this.props.dispatch(selected_menu_click(item));
	}
	handleSubcategory(subcategory,event){

			this.setState({hover:false});
	  this.props.dispatch(fetchsubitem(subcategory));
	}
	
	render(){
		const {isFetching,onChange,items,submenu,parentMenu}=this.props;

		
	const paperStyle = { minWidth:890,
  display: 'inline-block', overflow:'scroll',height:500,
  margin: '16px 32px 16px 0',position:'absolute',
    top:-16,
    bottom: 0,zIndex:1,  
    left: '100%',
    right: -30,
    overflowY:'auto',
	overflowX:'hidden'
};
     return (<div>
	 <div className="container dashboard_background">
	 <h1 className="aligncenter">About Paytm</h1>
	 </div>
	 <div className="container"> {/* Start of Container */}
	
 <div className="row mainSection">
 <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12 shopbycategories">
 <List onMouseEnter={this.toogleHover}
	 onMouseLeave={this.toogleHover}	 >
 <Subheader style={subHeaderStyle}>Shop by Category</Subheader>
	 {isFetching && items.length==0 && <div className="alingCenter"><CircularProgress size={60} thickness={5} /></div>}	
	{ !isFetching && items.map((item,i)=>
		 {return(<Link to={`${item}`} key={i}><ListItem className="listitem" innerDivStyle={{fontSize:'1.4rem',textTransform:'uppercase',padding:10}}
		 
		 primaryText={item} key={i} ref={item} onClick={this.handleClick.bind(null,item)} onMouseEnter={this.toogleSubDataHover.bind(null, item)}
		 />	 </Link>
)
		 }
		 )}
		 
		   
		    {this.state.hover && 
			<Paper className="paper" style={paperStyle}>
				{submenu.map((e,i)=>{ 
    return i%10===0 ? <div className="_3fbU" key={i}>
				{				
				submenu.slice(i,i+10).map((firstsubmenu,i)=>{
		  return(

  <List key={i}>
   <Link to={`product/${parentMenu}/${firstsubmenu.name.name}`} onClick={this.handleClick.bind(null,parentMenu)}><Subheader key={i} style={{color:'#000',cursor:'pointer',fontWeight:500,fontSize:'1.2rem',paddingLeft:10}} >{firstsubmenu.name.name}</Subheader></Link>
	   {typeof firstsubmenu.name.products !="undefined" && firstsubmenu.name.products.map((secondsubmenu,i)=>{
		    return(<Link to={`product/${parentMenu}/${firstsubmenu.name.name}/${secondsubmenu.name}`}><ListItem className="listitemsubmenu" innerDivStyle={{padding:10}} primaryText={secondsubmenu.name} key={i} /></Link>)				
	   }
	 )}
	 </List>  

	  )
			
			})

}
</div>	 : null; 
})
				}					
		
</Paper>
}

   
 </List>
 </div>
 {isFetching && items.length===0  &&<div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection" style={{padding:'0px 0px 8px',textAlign:'center'}}>
 <div className="alingCenter"><CircularProgress size={60} thickness={5} /></div>
		  <div className="selectedcategorytitle">Fetching Our Latest Offers</div>
		  </div>
		  </div>}
 { !isFetching && items.length!=0 && this.props.children}
 
</div>
{/* End of Container */}
</div>
</div>
	 )		

		
	}
}




const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer}=state;
const {isFetching,items,years,submenu,parentMenu}=fetchmenuReducer;

	console.log("sdkskdksdksmdksmdksmdksmdksmdksd",parentMenu);
return {isFetching,items,years,submenu,parentMenu};

}

export default connect(mapStateToProps)(Menus);