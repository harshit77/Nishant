import React from 'react';
import {List,ListItem} from 'material-ui/List';
import Paper from 'material-ui/Paper';
import Subheader from 'material-ui/Subheader';
import Maincontent from './Maincontent';
import CircularProgress from 'material-ui/CircularProgress';
const subHeaderStyle={color:"#00B9F5",
    fontWeight: 600,
    fontSize: 16};
export default class Menus extends React.Component{
	constructor(props){
		super(props);
		this.state={hover:false};
		this.toogleHover=this.toogleHover.bind(this);
		this.toogleSubDataHover=this.toogleSubDataHover.bind(this);
		this.handleClick=this.handleClick.bind(this);
		this.handleSubcategory=this.handleSubcategory.bind(this);
		this.handleAddProductRequest=this.handleAddProductRequest.bind(this);
	}
	
	toogleHover(){
		this.setState({hover:!this.state.hover});
		
	}
	toogleSubDataHover(item,event){
		
		this.props.onChange(item);
	}
	handleClick(item,layout,event)
	{
 $('html, body').animate({
        scrollTop: $(".features-grid").offset().top-60
    }, 2000);
	this.setState({hover:!this.state.hover});
		this.props.ondataClick(item,layout);
	}
	handleSubcategory(subcategory,layout,event){

			this.setState({hover:false});
		this.props.onsubcategoryClick(subcategory,layout);
	}
	handleAddProductRequest(addRequest,event)
	{
	this.props.handleAddProductAsyncRequest(addRequest);
	}
	render(){
		const {layout,selectedName,isListFetching,isFetching,onChange,menu,submenu,selectedmenuClick,listItemSubmenu,lastaddedProduct}=this.props;

		
	const paperStyle = { minWidth:890,
  display: 'inline-block', overflow:'scroll',height:500,
  margin: '16px 32px 16px 0',position:'absolute',
    top:-15,
    bottom: 0,zIndex:1,  
    left: '100%',
    right: -30,
    overflowY:'auto',
	overflowX:'hidden'
};
     return (
	 <div className="container"> {/* Start of Container */}
	
 <div className="row mainSection">
 <div className="col-lg-3 col-md-3 col-xs-12 col-sm-12 shopbycategories">
 <List onMouseEnter={this.toogleHover}
	 onMouseLeave={this.toogleHover}	 >
 <Subheader style={subHeaderStyle}>Shop by Category</Subheader>
	 {isFetching && menu.length==0 && <div className="alingCenter"><CircularProgress size={60} thickness={5} /></div>}	
	{ !isFetching && menu.map((item,i)=>
		 {return(<ListItem className="listitem" innerDivStyle={{fontSize:'1.4rem',textTransform:'uppercase',padding:10}}
		 
		 primaryText={item} key={i} ref={item} onClick={this.handleClick.bind(null,item,1)} onMouseEnter={this.toogleSubDataHover.bind(null, item)}
		 />	 
)
		 }
		 )}
		 
		   
		    {this.state.hover && 
			<Paper className="paper" style={paperStyle}>
				{submenu.map((e,i)=>{ 
    return i%10===0 ? <div className="_3fbU">
				{				
				submenu.slice(i,i+10).map((firstsubmenu,i)=>{
		  return(

  <List>
   <Subheader key={i} onClick={this.handleSubcategory.bind(null,firstsubmenu.name.name,2)}style={{color:'#000',cursor:'pointer',fontWeight:500,fontSize:'1.2rem',paddingLeft:10}} >{firstsubmenu.name.name}</Subheader>
	   {typeof firstsubmenu.name.items !="undefined" && firstsubmenu.name.items.map((secondsubmenu,i)=>{
		    return(<ListItem className="listitemsubmenu" innerDivStyle={{padding:10}} primaryText={secondsubmenu.name} key={i}/>)				
	   }
	 )}
	 </List>  

	  )
			
			})

}
</div>	 : null; 
})
				}					
		
</Paper>
}

   
 </List>
 </div>

 
 
 
 <Maincontent subcategoryInLayout={selectedmenuClick} handleSubcategory={this.handleSubcategory} isListFetching={isListFetching} listItemSubmenu={listItemSubmenu} selectedName={selectedName} layoutType={layout} handleAddProductRequest={this.handleAddProductRequest} 
lastadded={lastaddedProduct} />
 
</div>
{/* End of Container */}
</div>
	 )		

		
	}
}

Menus.propTypes = {
  menu: React.PropTypes.array.isRequired
}