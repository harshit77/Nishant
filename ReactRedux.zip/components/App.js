import React from 'react';
import Header from './Header';
import Flexisel from './Flexisel';
import MultipleViews from './MultipleViews';
import Menus from './Menus';
import Footer from './Footer';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();
export default class App extends React.Component{
	render(){return (
    <div>
	<MuiThemeProvider>
	<Header/>
	</MuiThemeProvider>

		<MuiThemeProvider>
	<MultipleViews/>
	</MuiThemeProvider>
<MuiThemeProvider>
{this.props.children}
</MuiThemeProvider>
<MuiThemeProvider>
<Flexisel/>
</MuiThemeProvider>

<MuiThemeProvider>
<Footer/>

</MuiThemeProvider>

    </div>
  )}
  
}