import React from 'react';
import {Tabs,Tab} from 'material-ui/Tabs';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import CircularProgress from 'material-ui/CircularProgress';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';import {connect} from 'react-redux';
import {selected_menu_click,fetchsubitem,recieve_product_status} from '../actions/actions';
class ProductList extends React.Component{

	constructor(props){
		super(props);
this.state={value:'a',currenIndex:0,handleSnackbar:false,largeView:false,layoutType:1};
this.handleChange=this.handleChange.bind(this);
this.handleLargeView=this.handleLargeView.bind(this);
this.handleClose=this.handleClose.bind(this);
this.handleAddProductRequest=this.handleAddProductRequest.bind(this);
}
handleLargeView()
{
	this.setState({handleSnackbar:false,largeView:true});
}
handleClose(){
    this.setState({handleSnackbar:false,largeView: false});
  }
handleChange(i,value)
{
	this.setState({handleSnackbar:false,currentValue:value,currenIndex:i,prevValue:this.state.value});
}
handleAddProductRequest(addRequest,event)
{
	  this.props.dispatch(recieve_product_status(addRequest));
	$("#"+addRequest).closest(".productcol").css({"cursor":"none",background:' rgba(247,246,207,0.4)'});
	$("#"+addRequest).attr('disabled', 'disabled');
}
componentWillReceiveProps(nextProps) {

    if (nextProps.lastadded !== this.props.lastadded) {
 	this.setState({handleSnackbar:true});
    }
  }

componentDidMount(){
	 $('html, body').animate({
        scrollTop: $(".features-grid").offset().top-60
    }, 2000);
	console.log(this.props.params.id);		this.props.dispatch(fetchsubitem(this.props.params.id));
}	
	
	
render(){
const {isListFetching,selectedmenuonclick,selectedcategoryName,Listitems,lastadded}=this.props;{/* missing layoutType*/}
var item=[];
if(Listitems.grid_layout)
{
 for(var element=0;element<Listitems.grid_layout.length;element++){
	 if(lastadded.length===0)
{ item.push(<div className="col-lg-3 col-md-3 col-xs-5 -col-sm-5 productcol">{/*<!--- Start of productcol-->*/}
<Tabs value={this.state.currenIndex===element ? this.state.currentValue : this.state.prevValue} key={element}  onChange={this.handleChange.bind(null,element)}>
<Tab label="View" value="a">
			   <div className="productDisplaySection">
<img src="C:/Users/753554/Downloads/checkonly.png" className="productimage"  onClick={this.handleLargeView} id={Listitems.grid_layout[element].product_id} />
		
			   </div>
			   <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{Listitems.grid_layout[element].name}</div>
			
			  <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',right: 20,top: 8}} >
			  <div className="dropdown">
  <button className="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    50%
    <span className="caret"></span>
  </button>
  <ul className="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
    <li role="separator" className="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>
</div>
			   </div>
			
			<div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
			<div className="priceSection">
			   <span className="amountafterdiscount">Rs {Listitems.grid_layout[element].offer_price}</span>
			   <span className="originalamount">{Listitems.grid_layout[element].actual_price}</span>
			   <span className="discountpercent">{Listitems.grid_layout[element].discount}</span>
			   </div>
			   </div>
			</Tab>
			<Tab label="Add / Buy" value="b">
          <div>
            <h2>Controllable Add / Buy ADD</h2>
            	 <RaisedButton label="cha" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
			 <RaisedButton label="Add" id={Listitems.grid_layout[element].product_id} secondary={true} onClick={this.handleAddProductRequest.bind(null,Listitems.grid_layout[element].product_id)}   style={{float:'right',minWidth:85}}/> 
			
          </div>
        </Tab>
 </Tabs>			
</div>			   );
}
for(var iterate=0;iterate<lastadded.length;iterate++)
{ 
 if(lastadded[iterate].name===Listitems.grid_layout[element].product_id)
{
item.push(<div className="col-lg-3 col-md-3 col-xs-5 -col-sm-5 productcol">{/*<!--- Start of productcol-->*/}
<Tabs value={this.state.currenIndex===element ? this.state.currentValue : this.state.prevValue} key={element}  onChange={this.handleChange.bind(null,element)}>
<Tab label="View" value="a">
			   <div className="productDisplaySection">
<img src="C:/Users/753554/Downloads/checkonly.png" className="productimage" onClick={this.handleLargeView} id={Listitems.grid_layout[element].product_id} />
			   </div>
			   <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{Listitems.grid_layout[element].name}</div>
			
			  <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',right: 20,top: 8}} >
			  <div className="dropdown">
  <button className="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    50%
    <span className="caret"></span>
  </button>
  <ul className="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
    <li role="separator" className="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>
</div>
			   </div>
			
			<div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
			<div className="priceSection">
			   <span className="amountafterdiscount">Rs {Listitems.grid_layout[element].offer_price}</span>
			   <span className="originalamount">{Listitems.grid_layout[element].actual_price}</span>
			   <span className="discountpercent">{Listitems.grid_layout[element].discount}</span>
			   </div>
			   </div>
			</Tab>
			<Tab label="Add / Buy" value="b">
          <div>
            <h2>Controllable Add / Buy Added</h2>
            	 <RaisedButton label="cha" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
				<RaisedButton label="Added" id={Listitems.grid_layout[element].product_id} secondary={true} style={{float:'right',minWidth:85}}/>  
			
          </div>
        </Tab>
 </Tabs>			
</div>			   );
break;
}
if(iterate+1==lastadded.length)
{ item.push(<div className="col-lg-3 col-md-3 col-xs-5 -col-sm-5 productcol">{/*<!--- Start of productcol-->*/}
<Tabs value={this.state.currenIndex===element ? this.state.currentValue : this.state.prevValue} key={element}  onChange={this.handleChange.bind(null,element)}>
<Tab label="View" value="a">
			   <div className="productDisplaySection">
<img src="C:/Users/753554/Downloads/checkonly.png" className="productimage" onClick={this.handleLargeView} id={Listitems.grid_layout[element].product_id} />
			   </div>
			   <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{Listitems.grid_layout[element].name}</div>
			
			  <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',right: 20,top: 8}} >
			  <div className="dropdown">
  <button className="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    50%
    <span className="caret"></span>
  </button>
  <ul className="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
    <li role="separator" className="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>
</div>
			   </div>
			
			<div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
			<div className="priceSection">
			   <span className="amountafterdiscount">Rs {Listitems.grid_layout[element].offer_price}</span>
			   <span className="originalamount">{Listitems.grid_layout[element].actual_price}</span>
			   <span className="discountpercent">{Listitems.grid_layout[element].discount}</span>
			   </div>
			   </div>
			</Tab>
			<Tab label="Add / Buy" value="b">
          <div>
            <h2>Controllable Add / Buy LAST</h2>
            	 <RaisedButton label="cha" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
				<RaisedButton label="Add" id={Listitems.grid_layout[element].product_id} secondary={true} onClick={this.handleAddProductRequest.bind(null,Listitems.grid_layout[element].product_id)}   style={{float:'right',minWidth:85}}/>
	
          </div>
        </Tab>
 </Tabs>			
</div>			   );
}
}
}

 
			  

}
	return(
	 <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
		  <div className="selectedcategorytitle">{selectedcategoryName}</div>
		  </div>
    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
      	{/*<!-- Wrapper for slides -->*/}   
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
         	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
           	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
	{/*<!-- End Carousel --> */} 




		
 	  {isListFetching && <div className="row features-loader"><div className="alingCenter"><CircularProgress size={70} thickness={6} /><div className="selectedcategorytitle">Fetching Our Latest Offers</div></div></div>}
		
		{!isListFetching &&<div className="row features-grid">
	 { typeof Listitems.grid_layout !="undefined" && item} 

</div>
		}

{ this.state.handleSnackbar===true && <Snackbar open={this.state.handleSnackbar} message={`wopiee Addedd Successfuly ${lastadded[lastadded.length-1].name}`} autoHideDuration={4000} />}

{this.state.largeView===true && 	   <Dialog
          title="Large View "
		  actions={<FlatButton
		  label="Ok"
		  primary={true}
		  onTouchTap={this.handleClose}
		  keyboardFocused={true}/>}
          modal={false}
          open={this.state.largeView}
          onRequestClose={this.handleClose}
         
        >
		<div className="row" style={{paddingTop:"10",borderTop:'1px solid rgb(224, 224, 224)'}}>
<div className="col-xs-6 col-md-6 col-lg-6 col-sm-6" style={{height:"300"}}><img src="C:/Users/753554/Downloads/checkonly.png" style={{width:"100%"}}/></div>
		<div className="col-xs-6 col-md-6 col-lg-6 col-sm-6 largeViewDialog" style={{height:"300"}}>
		<div className="largeviewTitle">Details</div>
		<div>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore 
		et dolore magna aliquyam erat, sed diam voluptua. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.</div>
		</div>
		</div>
        </Dialog>}
{/* End of MainContent */}

</div> 

	)
}	
	
}

const mapStateToProps=(state,ownProps)=>{
	const {listofAddProduct,fetchmenuReducer,fetchsubitemReducer}=state;
const {selectedcategoryName,selectedmenuonclick}=fetchmenuReducer;
const {lastadded}=listofAddProduct;
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
return {lastadded,selectedmenuonclick,isListFetching,Listitems,selectedcategoryName};

}


export default connect(mapStateToProps)(ProductList);