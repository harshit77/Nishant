import React from 'react';

export default class Foo extends React.Component {
	render(){
 return (<div>{this.props.params.pid} </div>)		
	}
	
 }