import React from 'react';
import AppBar from 'material-ui/AppBar';
import IconMenu  from 'material-ui/IconMenu';
import MenuItem from 'material-ui/MenuItem';
import IconButton from 'material-ui/IconButton/IconButton';
import TextField from 'material-ui/TextField';
import MapsPlace  from 'material-ui/svg-icons/maps/place';
import {List, ListItem} from 'material-ui/List';
import NavigationMenu from 'material-ui/svg-icons/navigation/menu';
import SocialPersonOutline from 'material-ui/svg-icons/social/person-outline';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import ActionInfo from 'material-ui/svg-icons/action/info';
import Badge from 'material-ui/Badge';
import Drawer from 'material-ui/Drawer';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import {select_submenu,selected_menu_click,fetchsubitem,fetchmenus,recieve_product_status} from '../actions/actions';

const styles = {
  radioButton: {
    marginTop: 16,
  }
};
const subHeaderStyle={color:"#00B9F5",
    fontWeight: 600,
    fontSize: 16};
class Header extends React.Component{
	constructor(props)
	{
		super(props);
		this.state={open:false,openDrawer:false};
	this.handleOpen=this.handleOpen.bind(this);
		this.handleClose=this.handleClose.bind(this);
		this.handleDrawerClose=this.handleDrawerClose.bind(this);
		this.handleDrawerMenu=this.handleDrawerMenu.bind(this);
		this.handleClick=this.handleClick.bind(this);
		this.handleRequestChange=this.handleRequestChange.bind(this);
	}
	componentDidMount(){const{dispatch}=this.props;
	dispatch(fetchmenus());
}
	  handleOpen(){
    this.setState({open: true});
  }
  handleClose(){
    this.setState({open: false});
  }
  handleDrawerClose(){
	this.setState({openDrawer:false});	
}
handleDrawerMenu(){
	
	this.setState({openDrawer:true});	
}
handleClick(item,layout,event)
	{ $('html, body').animate({
        scrollTop: $(".features-grid").offset().top-60
    }, 2000);
	this.setState({openDrawer:false});
 this.props.dispatch(selected_menu_click(item));
	}
	handleRequestChange(open)
	{ this.setState({openDrawer: open});
		
	}
	render(){
		const {items,lastadded,isFetching}=this.props;
		
		 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
     <FlatButton
        label="Submit"
        primary={true}
     
 containerElement={<Link to="/checkout"/>}
  linkButton={true}
        onTouchTap={this.handleClose}
	    style={{overflow:'none'}} />,
    ];

	
	
		return (
		<AppBar 
		title="Title" iconStyleRight={{width:"80%",marginTop:0}}  titleStyle={{color:"rgb(0, 188, 212)"}} style={{backgroundColor:"#fff",position:"fixed",boxShadow: "rgba(0, 0, 0, 0.298039) 0px 19px 60px, rgba(0, 0, 0, 0.219608) 0px 15px 20px"}}
		 iconElementLeft={<IconButton  onTouchTap={this.handleDrawerMenu} tooltip="Menu" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><NavigationMenu/>
		
		 		 </IconButton>}
		iconElementRight={
		<div>
		<div className="visible-sm-inline-block visible-md-inline-block visible-lg-inline-block" style={{width:"90%"}}>
 <TextField  className="searchbox"
      hintText="Hint Text" style={{width:"inherit"}}
      floatingLabelText="Baby Search Here....."
    />
	</div>
		<div className="visible-xs-inline-block" style={{width:"90%"}}>
 <TextField  className="searchbox"
      hintText="Hint Text" style={{width:"100%"}}
      floatingLabelText="Baby Search Here....."
    />
	</div>
	<IconMenu style={{position:"fixed",right: 0,top:10}}
iconButtonElement={<IconButton tooltip="Login" tooltipPosition="bottom-center" ><SocialPersonOutline /></IconButton>}
	anchorOrigin={{horizontal:'left',vertical:'top'}} targetOrigin={{horizontal:'left',vertical:'top'}} maxHeight={272} >
		<MenuItem primaryText="Refresh" />
      <MenuItem primaryText="Send feedback" />
      <MenuItem primaryText="Settings" />
      <MenuItem primaryText="Help" />
      <MenuItem primaryText="Sign out" />
		</IconMenu>
		 <IconMenu style={{position:"fixed",right:37,top:10}} 
     iconButtonElement={<IconButton tooltip="Change Location" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><MapsPlace/></IconButton>} 
      anchorOrigin={{horizontal: 'left', vertical: 'top'}}
      targetOrigin={{horizontal: 'left', vertical: 'top'}}
    >
      <MenuItem primaryText="Lucknow" />
      <MenuItem primaryText="Agra" />
    </IconMenu>
		<Badge
		badgeContent={lastadded.length===0 ? 0:lastadded.length} primary={true} style={{position:"fixed",right:87,cursor:'pointer',width:22,height:22}} badgeStyle={{top:7,right:-10,width:20,height:20}}> 
		<NotificationsIcon onTouchTap={this.handleOpen}/>
		</Badge>
		<Dialog
          title="Scrollable Dialog"
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
          autoScrollBodyContent={true}
        >
          <List>
		  {lastadded.length!=0 && lastadded.map((addedItem,i)=>{
			 return( <ListItem
          key={i}
          primaryText={addedItem.name}
          rightIcon={<ActionInfo />}
		  />) 
		  })
		  }
      </List>
        </Dialog>
		 <Drawer 
		docked={false} 
		width={250}
		open={this.state.openDrawer}
		 onRequestChange={this.handleRequestChange}
		 >

		 <Subheader style={subHeaderStyle}>Shop by Category</Subheader>
	 {isFetching && items.length==0 && <div className="alingCenter"><CircularProgress size={60} thickness={7} /></div>}	
			{!isFetching && items.map((item,i)=>
		 {return(<Link to={`/paytm/${item}`} key={i}><MenuItem  className="listitem" innerDivStyle={{fontSize:'1.4rem',textTransform:'uppercase',padding:10,lineHeight:0,marginTop:10}}
		 
		 primaryText={item} key={i} ref={item} onClick={this.handleClick.bind(null,item,1)}
		 />	 </Link>
)
		 }
		 )}
		
		</Drawer>
		</div>
		}/>
		)
	}
}


const mapStateToProps=(state,ownProps)=>{
	const {listofAddProduct,fetchmenuReducer}=state;
const {isFetching,items}=fetchmenuReducer;
const {lastadded}=listofAddProduct;
return {lastadded,isFetching,items};

}

export default connect(mapStateToProps)(Header);