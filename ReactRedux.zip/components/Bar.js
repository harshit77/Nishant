import React from 'react';

export default class Bar extends React.Component {
	render(){
 return (<div>And I am Bar!</div>)		
	}
	
 }