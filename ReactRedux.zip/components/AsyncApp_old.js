import React from 'react';
import Header from './Header';
import Flexisel from './Flexisel';
import GeneralView from './GeneralView';
import {connect} from 'react-redux';
import {select_submenu,selected_menu_click,fetchsubitem,fetchmenus,recieve_product_status} from '../actions/actions';
import Menus from './Menus';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();
class AsyncApp extends React.Component{
constructor(props){
	super(props);
	this.handleChange = this.handleChange.bind(this);
	this.state={layout:1,selectedName:'Home'}
	this.handledataClick=this.handledataClick.bind(this);
	this.handleAddProductAsyncRequest=this.handleAddProductAsyncRequest.bind(this);
	this.handleSubcategorydata=this.handleSubcategorydata.bind(this);
}
componentDidMount(){const{dispatch}=this.props;
	dispatch(fetchmenus());
}
handleChange(nextsubmenuSelected) {
    this.props.dispatch(select_submenu(nextsubmenuSelected));
  }
  handledataClick(selectedClick,layout)
  { this.setState({layout:layout,selectedName:selectedClick});
  this.props.dispatch(selected_menu_click(selectedClick));
  }
  handleSubcategorydata(subCategoryclicked,layout)
  {this.setState({layout:layout,selectedName:subCategoryclicked});
  this.props.dispatch(fetchsubitem(subCategoryclicked));
	  
  }
  handleAddProductAsyncRequest(addRequest)
  {
	  this.props.dispatch(recieve_product_status(addRequest));
  }
 
render(){
	const {lastadded,isFetching,items,selectedmenuonclick,years,submenu,isListFetching,Listitems}=this.props;

	return(<div>
	
<MuiThemeProvider>
	<Header menu={items} lastaddedProduct={lastadded} ondataClick={this.handledataClick} isFetching={isFetching} />
	</MuiThemeProvider>
	<MuiThemeProvider>
	<GeneralView/>
	</MuiThemeProvider>
	
<MuiThemeProvider>
<Menus menu={items} submenu={submenu} lastaddedProduct={lastadded} ondataClick={this.handledataClick} handleAddProductAsyncRequest={this.handleAddProductAsyncRequest} listItemSubmenu={Listitems} onsubcategoryClick={this.handleSubcategorydata}
 selectedmenuClick={selectedmenuonclick} onChange={this.handleChange} layout={this.state.layout} selectedName={this.state.selectedName} isFetching={isFetching} isListFetching={isListFetching}/>	
</MuiThemeProvider>
<MuiThemeProvider>
<Flexisel/>
</MuiThemeProvider>

</div>)	
}
	
}

const mapStateToProps=(state,ownProps)=>{
	const {listofAddProduct,fetchmenuReducer,fetchsubitemReducer}=state;
const {isFetching,items,years,submenu,selectedmenuonclick}=fetchmenuReducer;
const {lastadded}=listofAddProduct;
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
return {lastadded,isFetching,items,years,submenu,selectedmenuonclick,isListFetching,Listitems};

}

export default connect(mapStateToProps)(AsyncApp);