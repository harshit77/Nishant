import React from 'react';
import CircularProgress from 'material-ui/CircularProgress';
class CheckoutMainContainer extends React.Component {

constructor(props)
{
	super(props);
	this.state={lazyLoading:null};
}
async componentDidMount()
{
	const {default: Checkout}= await import ('./Checkout');
	this.setState({lazyLoading:<Checkout/>});
}
   render() {

      return (
         <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
            <div className="row shopcategoriesSection">
               <div className="selectedcategorytitle">Checkout</div>
             </div>
            {this.state.lazyLoading || <div className="alingCenter"><CircularProgress size={60} thickness={5} /></div>}
         </div>
      );
   }
}

export default CheckoutMainContainer;