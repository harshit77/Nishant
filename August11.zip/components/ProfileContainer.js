import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import {Field,reduxForm,change} from 'redux-form';
import ProfileSubmit from './ProfileSubmit';
import RaisedButton from 'material-ui/RaisedButton';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton'
import TextField from 'material-ui/TextField';
import {fetchProfile} from '../actions/actions';
import {connect} from 'react-redux';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';



const validate=values=>{
	const errors={};
	
	const requiredFields=['firstName','lastName','emailId','address','mobileNumber','gender'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  	})
	 if (
    values.email &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email))
  ) {
    errors.email = 'Invalid email address'
  }
  else if(values.firstname &&  (!/^[a-z]+$/i.test(values.firstName)))
  {
  	errors.firstName = 'Invalid firstName'
  }
   else if(values.lastname &&  (!/^[a-z]+$/i.test(values.lastName)))
  {
  	errors.lastName = 'Invalid lastName'
  }
  else  if (values.mobileNumber && (!/^[7-9]{1}[0-9]{9}$/i.test(values.mobileNumber)))
 	{
    errors.mobileNumber = 'Invalid Mobile Number'
  }




	 else if(values.city=="NotSelected")
		 {errors.city="Select Your Choice";
	}
		console.log("Errors",errors)
	return errors;
}

const renderRadioGroup = ({ input, children }) => (
  <RadioButtonGroup
    {...input}
   children={children}
    valueSelected={input.value}
    onChange={(event, value) => input.onChange(value)}
  />
)
const renderTextField=({
input,
label,
type,
userId,
meta:{touched,error},
custom,
})=>{console.log(input.value );
	return (label==="Address of delivery" ? 
		<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} multiLine={true} rows={2}/> 
		:
			<TextField hintText={label} type={type} floatingLabelText={label}  disabled={userId==input.value ? true :false} errorText={touched && error} {...input} /> 
		)

}


const jsonFile={
      states:[
        { name: 'Uttar Pradesh',  city: ['Lucknow', 'Kanpur']},
      ],
    }
var cityFilter;
class ProfileContainer extends React.Component
{
	constructor(props)
	{
		super(props);
		this.state={selectedState:jsonFile.states[0].name,selectedCity:jsonFile.states[0],isLoaded:false};
		this.handleChange=this.handleChange.bind(this);
		this.renderSelectField=this.renderSelectField.bind(this);
	}
	componentDidMount()
	{
		this.props.dispatch(fetchProfile());
	}

 renderSelectField({
	input,
	label,
	meta:{invalid,error},
	children
}){ 
return (
	label==="State" ? 
		<SelectField 
			floatingLabelText={label}
			errorText={invalid && error}
			{...input}
			value={this.state.selectedState}
	    	onChange={this.handleChange.bind(null,input)}
	    	children={children}
    		/>
    		:

    		<SelectField 
			floatingLabelText={label}
			errorText={invalid && error}
			{...input}
	    	onChange={(event, index, value) => input.onChange(value)}
	    	children={children}
	    	/>
	)


}
	handleChange(input,event,key,payload)
	{	console.log("fdsfmnkdnf",payload);
	
	input.onChange(payload);
	 cityFilter=jsonFile.states.filter(item=>{
			return item.name===payload;
		});

	 console.log("CityFilter",cityFilter);
		this.setState({selectedState:payload,selectedCity:cityFilter[0]});
		this.props.fields.city.onChange('NotSelected')
	}
	render()
	{console.log("Rebder",this.state.selectedState);
			const {error,handleSubmit,pristine,reset,submitting,invalid,submitSucceeded,userId}=this.props;

		return(
		<div>
			<form onSubmit={handleSubmit(ProfileSubmit)}>

				<div>
				{userId!=null 
					&& submitSucceeded===true && <p className="success">Profile Updated Successfully </p>}
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
				


					<div>
						<Field name="firstName" component={renderTextField} label="First Name" type="text"/>
					</div>
					<div>
						<Field name="lastName" component={renderTextField} label="Last Name" type="text"/>
					</div>
					<div>
						<Field name="address" component={renderTextField} label="Address of delivery" type="text" />
					</div>
					<div>
						<Field name="emailId" component={renderTextField} label="Email Id" type="text" userId={userId}/>
					</div>

				<div>
				    <Field
         				 name="state"
         				 component={this.renderSelectField}
          				 label="State"
          				 value={this.state.selectedState}
        				 >
        				 {jsonFile.states.map((stateName,index)=>{
			        	console.log(stateName.name);
			        	return (<MenuItem value={stateName.name} key={index}  primaryText={stateName.name} />)
			              })}
			        </Field>
				 </div>
				{this.state.selectedCity!=null &&
			   <div>
			        <Field
         		 name="city"
         			component={this.renderSelectField}
          				label="City"

          				
        				>
        				 {
			        	this.state.selectedCity.city.map((item,index)=>{
			        		return (<MenuItem value={item} key={index} primaryText={item} />)
			        	})
			        }
			        </Field>
			        </div>

			       
}
 					<div>
						<Field name="mobileNumber" component={renderTextField} label="Mobile Number" type="text" userId={userId}/>
					</div>
					<div>
						<Field name="alternateMobileNumber" component={renderTextField} label="Alternate Mobile Number" type="text"/>
					</div>
	<div>
        <Field name="gender" component={renderRadioGroup}>
          <RadioButton value="male" label="male" />
          <RadioButton value="female" label="female" />
        </Field>
      </div>

      <RaisedButton
          label="Save My Profile"          
          primary={true} style={{margin:'20px 0'}}
          disabled={pristine || submitting || invalid}
		       type="submit"    
        />
			
</form>
</div>
		 )

	}
}


ProfileContainer=reduxForm({
	form:'profilecontainer',
	validate,
	enableReinitialize:true
})(ProfileContainer);

const mapStateToProps=(state,ownProps)=>{
	const {Profile,fetchmenuReducer}=state;
	const {userId}=fetchmenuReducer;
	const initialValues=Profile.userProfile;
	console.log("Inside profilecontainer",initialValues);
	return {initialValues,userId};
}


export default connect(mapStateToProps)(ProfileContainer);