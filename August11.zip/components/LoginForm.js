import React from 'react';
import {Field,reduxForm} from 'redux-form';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem'
import SelectField from 'material-ui/SelectField'
import {intialState} from './../actions/actions';
import {connect} from 'react-redux';
import Submit from './Submit';
import RaisedButton from 'material-ui/RaisedButton';
import Divider from 'material-ui/Divider';
import ForgetPassword from './ForgetPassword';
import Subheader from 'material-ui/Subheader';

import Avatar from 'material-ui/Avatar';
import Chip from 'material-ui/Chip';
import SvgIconFace from 'material-ui/svg-icons/action/face';


const validate=values=>{
	const errors={};
	const requiredFields=['username','password'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })



 if (
    values.username &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.username) && !/^[7-9]{1}[0-9]{9}$/i.test(values.username))
  ) {
    errors.username = isNaN(values.username)===true ?'Invalid email address' :"Invalid Mobile Number";
  }
	 return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
	return (
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
		)

}


class LoginForm extends React.Component
{
	constructor(props)
	{
		super(props)
		this.state={forgetpassword:false};
		this.handleActiveForgetLink=this.handleActiveForgetLink.bind(this);
	}

handleActiveForgetLink()
{
	this.setState({forgetpassword:true})
}

		render()
	{
		const {error,handleSubmit,pristine,invalid,reset,submitting,userId}=this.props;
		return(<div style={{textAlign:'center'}}>
			
				{this.state.forgetpassword===false &&
					<div>
					<form onSubmit={handleSubmit(Submit)}>
				<div>
				{userId!=null 
					&& <p className="success">Login is succesfull</p>}
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
					<div>
					<Field name="username" component={renderTextField} label="Mobile Number or Email id" type="text"/>
					</div>
					
					<div>
						<Field name="password" component={renderTextField} label="Password" type="password"/>
					</div>
				
					<div>
					<RaisedButton
          label="Login"          
          primary={true} style={{margin:'20px 0'}}
          disabled={invalid || pristine || submitting}
		       type="submit"    
        />
					 </div>

				 <div>
				 <Chip onTouchTap={this.handleActiveForgetLink} style={{margin:'0 auto',backgroundColor:'none'}}>
			          <Avatar icon={<SvgIconFace  />}  style={{color:'rgb(0, 188, 212)'}}/>
			          ForgetPassword ?
			        </Chip>
        </div>
				</form>

					<Divider style={{marginTop:10,marginBottom:10}}/>
				<div style={{marginTop:25}} >
				 <RaisedButton
			          label="Facebook"          
			          primary={true} 
					           
			        />
				<RaisedButton label="Google" labelColor="#fff" style={{marginLeft:20}} backgroundColor="rgb(38, 166, 154)" />
 				 </div>
 				 </div>

 				}

 				{this.state.forgetpassword===true && <ForgetPassword/>}


				</div>
				
			  )
	}

}

LoginForm=reduxForm({
	form:'LoginForm',
	validate
})(LoginForm);

const mapStateToProps=(state)=>{
 const {fetchmenuReducer}=state;
 const {userId}=fetchmenuReducer;
console.log("Inside mapStateToProps");
 return {userId};

}





export default connect(mapStateToProps)(LoginForm);