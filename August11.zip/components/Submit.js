import {SubmissionError} from 'redux-form';
import {saveUserIdAfterLogin} from './../actions/actions';

const Sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));


const Submit=(values,dispatch)=>{
	
	return fetch('http://54.254.254.57:8080/hsahu/api/user/login',{
	method: 'post',mode: 'cors',credentials: 'same-origin',
	body: JSON.stringify({
		"userName":values.username,
		"password":values.password,
	}),
	headers: new Headers({
		'Content-Type': 'application/json'
	})
}).then(response =>{

		if(response.status===200)
		return response.json()
		else
			throw new SubmissionError({_error:response.statusText})
        // submission was successful
      }, errors => {
        console.log('request failed', error); throw new SubmissionError({_error:"! Some Network Issue"}) 
        // submission was unsuccessful
      }).then((json)=>{console.log(json);

      	if(json.data!=null)
	      {	if(json.data['user-name']!==undefined)
	      	{
	      			dispatch(saveUserIdAfterLogin(json.data['user-name']));
	      	}
	      	else
	      	{
	      		throw new SubmissionError({_error:json.data})
	      	}
	      }
	      else
	      {
	      	throw new SubmissionError({_error:json.message});
	      }
      })		;


// return Sleep(1000).then(()=>{
// 		if(!['harshit','Vatsalya','Rishi'].includes(values.username))
// 			 throw new SubmissionError({username:"Username does not exists",_error:"! Login Failed"})
// 		else if(values.password!=="redux-form")
// 			throw new SubmissionError({password:"Wrong password",_error:"! Login Failed"})
// 		else
// 			console.log(`You Submitted \n \n ${JSON.stringify(values,null,2)}`);
// })
}
export default Submit;