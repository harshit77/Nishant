import React from 'react';
import {Field,reduxForm} from 'redux-form';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem'
import SelectField from 'material-ui/SelectField'
import {intialState} from './../actions/actions';
import {connect} from 'react-redux';
import RegisterSubmit from './RegisterSubmit';
import RaisedButton from 'material-ui/RaisedButton';
import Divider from 'material-ui/Divider';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';

const validate=values=>{
	const errors={};
	const requiredFields=['username','password','confirmPassword'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })



 if (
    values.username &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.username) && !/^[7-9]{1}[0-9]{9}$/i.test(values.username))
  ) {
    errors.username = isNaN(values.username)===true ?'Invalid email address' :"Invalid Mobile Number";
  }

  else if(values.password!=values.confirmPassword){
  	errors.confirmPassword="Password did not match";

  }

	 return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
	return (
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
		)

}


class RegisterForm extends React.Component
{
	constructor(props)
	{
		super(props)
	}
	render()
	{
		const {error,handleSubmit,pristine,invalid,reset,submitting,userId,submitSucceeded}=this.props;
		return(<div style={{textAlign:'center'}}>
			
				{submitting=== false ? 
				<form onSubmit={handleSubmit(RegisterSubmit)}>
				<div>
				{submitSucceeded===true && <p className="success">Thanks for Registering With </p> }
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
				{(submitSucceeded===undefined ||submitSucceeded===false) &&
				<div>
					<div>
					<Field name="username" component={renderTextField} label="Mobile Number or Email id" type="text"/>
					</div>
					
					<div>
						<Field name="password" component={renderTextField} label="Password" type="password"/>
					</div>
					<div>
						<Field name="confirmPassword" component={renderTextField} label="ConfirmPassword" type="password"/>
					</div>
				
					<div>
					<RaisedButton
          label="Register"          
          primary={true} style={{margin:'20px 0'}}
         disabled={pristine || submitting || invalid}
		       type="submit"    
        />
					 </div>
					 </div>
					}
				</form>
				:
				<CircularProgress size={80} thickness={5} />

			}

					<Divider style={{marginTop:10,marginBottom:10}}/>
				<div style={{marginTop:25}} >
				 <RaisedButton
          label="Facebook"          
          primary={true} 
		           
        />
				<RaisedButton label="Google" labelColor="#fff" style={{marginLeft:20}} backgroundColor="rgb(38, 166, 154)" />
 				 </div>

				</div>
				




			  )
	}

}

RegisterForm=reduxForm({
	form:'RegisterForm',
	validate
})(RegisterForm);





export default RegisterForm;