    {/*<!-- Wrapper for slides -->*/} 
    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
      	  
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
         	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
           	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
	<!-- End Carousel --> */} 








 {/*<!-- pRODUCT lISTiTEM -->*/}   


    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
        {/*<!-- Wrapper for slides -->*/}   
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
          {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
            {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
  {/*<!-- End Carousel --> */} 


















<div className="col-lg-3 col-md-3 col-xs-5 col-sm-5 productcol" key={element} id={element[position].id}>{/*<!--- Start of productcol-->*/}

         <div className="productDisplaySection">
            <img src="C:/Users/753554/Downloads/checkonly.png" className="productimage"  onClick={this.handleLargeView.bind(null,element[position])}  />
         </div>
         <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{element[position].name}</div>
      
        <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',padding:0,top:0}} >
          <DropDownMenu value={element[position].id}  underlineStyle={{margin:'-1px 0',right:'35px'}} labelStyle={{paddingLeft:0}} onChange={this.handleChangeinDropDown.bind(null,element[position],element[position].id)}>
              { element[position].childProducts.map((childProduct,index)=>{    
                    return ( <MenuItem key={index} value={childProduct.id}  primaryText={`${childProduct.productQuantity} ${childProduct.productUnit}`} />)

                })
              }
           </DropDownMenu>
        </div>
         <div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
              <div className="priceSection">
                     <span className="amountafterdiscount">Rs {element[position].discountedPrice}</span>
                     <span className="originalamount">{element[position].productPrice}</span>
                     <span className="discountpercent">{`${element[position].discountPerCent}%`}</span>
              </div>
         </div>
         <RaisedButton label="BUY" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
          <RaisedButton label="Add" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
         </div>
        



        






// <ul id="flexiselDemo2"> 
//                  <li><img src="http://9bitstudios.github.io/flexisel/images/logo-adidas.png" /></li>     
//                  <li><img src="http://9bitstudios.github.io/flexisel/images/logo-nike.png" /></li> 
//                  <li><img src="http://9bitstudios.github.io/flexisel/images/logo-amazon.png" /></li> 
//                  <li><img src="http://9bitstudios.github.io/flexisel/images/logo-spotify.png" /></li> 
//                  <li><img src="http://9bitstudios.github.io/flexisel/images/logo-android.png" /></li>                                                                            
//              </ul>