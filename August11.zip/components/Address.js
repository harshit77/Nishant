import React from 'react';
import MenuItem from 'material-ui/MenuItem';
import {Field,reduxForm} from 'redux-form';
import AddressSubmit from './AddressSubmit';
import TextField from 'material-ui/TextField';
import Subheader from 'material-ui/Subheader';
import {connect} from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';

const validate=values=>{
	const errors={};
	
	const requiredFields=['firstName','lastName','address','mobileNumber'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  	})
	 if (
    values.email &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email))
  ) {
    errors.email = 'Invalid email address'
  }
  else if(values.firstname &&  (!/^[a-z]+$/i.test(values.firstName)))
  {
  	errors.firstName = 'Invalid firstName'
  }
   else if(values.lastname &&  (!/^[a-z]+$/i.test(values.lastName)))
  {
  	errors.lastName = 'Invalid lastName'
  }
  else  if (values.mobileNumber && (!/^[7-9]{1}[0-9]{9}$/i.test(values.mobileNumber)))
 	{
    errors.mobileNumber = 'Invalid Mobile Number'
  }

		console.log("Errors",errors)
	return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{console.log(custom);
	return (label==="Address of delivery" ? 
		<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} multiLine={true} rows={2}/> 
		:
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} /> 
		)

}


class Address extends React.Component
{
	constructor(props)
	{
		super(props);
	}

	
	render()
	{
			const {error,handleSubmit,pristine,reset,submitting,invalid,submitSucceeded,userId}=this.props;
		return(
		<div>
			<form onSubmit={handleSubmit(AddressSubmit)}>

				<div>
				{userId!=null 
					&& submitSucceeded===true && <p className="success">Address Updated Successfully </p>}
				</div>
				<Subheader style={{color:'red',textAlign:'center'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
				


					<div>
						<Field name="firstName" component={renderTextField} label="First Name" type="text"/>
					</div>
					<div>
						<Field name="lastName" component={renderTextField} label="Last Name" type="text"/>
					</div>
					<div>
						<Field name="address" component={renderTextField} label="Address of delivery" type="text" />
					</div>
					<div>
						<Field name="emailId" component={renderTextField} label="Email Id (Optional)" type="text" />
					</div>

				
 					<div>
						<Field name="mobileNumber" component={renderTextField} label="Mobile Number" type="text"/>
					</div>
					<div>
						<Field name="alternateMobileNumber" component={renderTextField} label="Mobile Number(Optional)" type="text"/>
					</div>
	

      <RaisedButton
          label="Save Address"          
          primary={true} style={{margin:'20px 0'}}
          disabled={pristine || submitting || invalid}
		       type="submit"    
        />
			
</form>
</div>
		 )

	}
}


Address=reduxForm({
	form:'address',
	validate
})(Address);


const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer}=state;
	const {userId}=fetchmenuReducer;
	return {userId};
}


export default connect(mapStateToProps)(Address);
