import React from 'react';
import {Tabs, Tab} from 'material-ui/Tabs';
import FontIcon from 'material-ui/FontIcon';
import MapsPersonPin from 'material-ui/svg-icons/maps/person-pin';
import SocialPersonAdd from 'material-ui/svg-icons/social/person-add';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';





export default class TabsControlled extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      value:'sectionA',
    };
    this.handleChange=this.handleChange.bind(this);
  }

  handleChange(value){
    this.setState({
      value: value,
    });
  };

  render() {
    return (
      <Tabs
        value={this.state.value}
        onChange={this.handleChange}
        inkBarStyle={{backgroundColor:'#012b72'}}
      >
        <Tab  icon={<MapsPersonPin/>} label="Login" value="sectionA">
          <div>
            {this.state.value==="sectionA" ? <LoginForm/>:null}
          </div>
        </Tab>
        <Tab icon={<SocialPersonAdd/>} label="SignUp" value="sectionB">
          <div>
          {this.state.value==="sectionB" ? <RegisterForm/>:null}
          </div>
        </Tab>
      </Tabs>
    );
  }
}