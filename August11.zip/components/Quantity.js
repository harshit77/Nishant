import React from 'react';
import ActionAndroid from 'material-ui/svg-icons/action/android';
import ContentAddCircle from 'material-ui/svg-icons/content/add-circle';
import ContentRemoveCircle from 'material-ui/svg-icons/content/remove-circle';
import IconButton from 'material-ui/IconButton';
import QuantityCss from './css/QuantityCss';


export default class Quantity extends React.Component {
constructor(props)
{
	super(props);
	this.handleQuantity=this.handleQuantity.bind(this);
}
handleQuantity(value,id)
{ console.log(value,id);
this.props.productQuantityChange(value==="Increment" ? this.props.productQuantity+1 :this.props.productQuantity-1,id);
}

render(){
return(
<div style={QuantityCss.productQuantity}>
<IconButton tooltip="SVG Icon" onTouchTap={this.handleQuantity.bind(null,"Decrement",this.props.productId)}>
  <ContentRemoveCircle />
</IconButton>

<div style={QuantityCss.quantityText}>{this.props.productQuantity}</div>
<IconButton tooltip="SVG Icon" >
  <ContentAddCircle onTouchTap={this.handleQuantity.bind(null,"Increment",this.props.productId)} />
</IconButton>
<div style={QuantityCss.productPrice}>Rs {this.props.productPrice}</div>
</div>)
	
}
  
}
