import React from 'react';
import {Field,reduxForm} from 'redux-form';
import {connect} from 'react-redux';
import CircularProgress from 'material-ui/CircularProgress';
import RaisedButton from 'material-ui/RaisedButton';
import Subheader from 'material-ui/Subheader';
import TextField from 'material-ui/TextField';
import ChangePasswordSubmit from './ChangePasswordSubmit';


const validate=values=>{
	const errors={};
	const requiredFields=['oldPassword','newPassword','confirmPassword'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })



   if(values.newPassword!=values.confirmPassword){
  	errors.confirmPassword="Password did not match";

  }

	 return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
	return (
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
		)

}



class ChangePassword extends React.Component
{
	constructor(props)
	{
		super(props);

	}
	render()
	{	const {error,handleSubmit,pristine,invalid,reset,submitting,userId,submitSucceeded}=this.props;
		return(
			<div>
			{userId==undefined   &&
			 <div className="row features-loader">
				 <div className="alingCenter"><CircularProgress size={70} thickness={6} />
				 <div className="selectedcategorytitle">Fetching Account details</div>
				 </div>
			 </div>

			}

			{userId!=null &&
					

					<div style={{textAlign:'center'}}>
			
				{submitting=== false ? 
				<form onSubmit={handleSubmit(ChangePasswordSubmit)}>
				<div>
				{submitSucceeded===true && <p className="success">Password Change Succesfully </p> }
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
				{(submitSucceeded===undefined ||submitSucceeded===false) &&
				<div>
					<div>
						<Field name="oldPassword" component={renderTextField} label="Old Password" type="password"/>
					</div>
					<div>
						<Field name="newPassword" component={renderTextField} label="NewPassword" type="password"/>
					</div>
				
					<div>
						<Field name="confirmPassword" component={renderTextField} label="ConfirmPassword" type="password"/>
					</div>
				
					<div>
					<RaisedButton
          label="Change Password"          
          primary={true} style={{margin:'20px 0'}}
         disabled={pristine || submitting || invalid}
		       type="submit"    
        />
					 </div>
					 </div>
					}
				</form>
				:
				<CircularProgress size={80} thickness={5} />

			}
				

				</div>
				




			}
			{userId===null &&
				<div>
				User is not logged In
				</div>
			}
			</div>
			)
	}
}

ChangePassword=reduxForm({
	form:'changepassword',
	validate
})(ChangePassword);



const mapStateToProps=(state)=>
{
const {fetchmenuReducer}=state;
const {isFetching,items,cartDetails,status,userId}=fetchmenuReducer;
return {userId};

}
export default connect(mapStateToProps)(ChangePassword);