import React from 'react';
import CircularProgress from 'material-ui/CircularProgress';
class Profile extends React.Component {

constructor(props)
{
	super(props);
	this.state={lazyLoading:null};
}
async componentDidMount()
{
	const {default: ProfileContainer}= await import ('./ProfileContainer');
	this.setState({lazyLoading:<ProfileContainer/>});
}
componentDidUpdate()
{
    setTimeout(() => {
                window.dispatchEvent(new Event('resize'));
        },10);
}
   render() {

      return (
         <div>
            {this.state.lazyLoading || <div className="alingCenter"><CircularProgress size={60} thickness={5} /></div>}
         </div>
      );
   }
}

export default Profile;