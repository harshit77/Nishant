import fetch from 'isomorphic-fetch';
 
export const SELECT_SUBMENU="SELECT_SUBMENU";
 
export function select_submenu(submenu){
	console.log("Hoveriiiiiing",submenu);
	return {
		type:SELECT_SUBMENU,
		submenu
	}
	
} 

export const SELECTED_MENU_CLICK="SELECTED_MENU_CLICK";

export const selected_menu_click=(selectedmenuonClick)=>{
	console.log(selectedmenuonClick);
	return {
		type:SELECTED_MENU_CLICK,
		selectedmenuonClick:selectedmenuonClick
	}
	
}

export const REQUEST_SUBITEM="REQUEST_SUBITEM";
export const request_subItem=()=>{
	return {
	type:REQUEST_SUBITEM	
	}	
}

export const RECIEVE_FETCHSUBITEM="RECIEVE_FETCHSUBITEM";

export const fetchsubitem=(subcategoryItem)=>{
	return (dispatch)=>{
			dispatch(request_subItem());
		return fetch(`http://www.json-generator.com/api/json/get/ceVKPjaGeW`).then(response=>response.json()).
		then(json=>dispatch(recieveFetchSubitem(subcategoryItem,json)));
	}
	
}
export const recieveFetchSubitem=(subcategoryItem,json)=>{
	return {
		type:RECIEVE_FETCHSUBITEM,
		subcategoryItem,
		itemList:json
	}
}

export const REQUEST_MENU="REQUEST_MENU";
export const requestMenus=()=>{
	return {
	type:REQUEST_MENU	
	}	
}

export const RECIEVE_FETCHMENU="RECIEVE_FETCHMENU";
 
export const fetchmenus=()=>{

	return (dispatch)=>{
		dispatch(requestMenus());
		return fetch('http://54.254.254.57:8080/hsahu/api/menu-list/0',{credentials: 'same-origin',
	 method: "GET",
        headers: {
            "Accept": "application/json"
        }
    }).then(response=>response.json()).
		then(json=> dispatch(recieveFetchmenu(json)));
		
	}
	
}

export const recieveFetchmenu=(json)=>{
	

	return{
		type:RECIEVE_FETCHMENU,
	dataformenus:json.data.categories.map(category=>category.name),
	values:json.data.categories,
	sectionList:json.data.sectnList,
	specialOffers:json.data.offerList,
	cartDetails:json.data.cart,
	userId:json.data.userName
	}
	
}

export const CHECK_PRODUCT_STATUS="CHECK_PRODUCT_STATUS";
export const fetch_product_status=(productID,cartId,productQuantity)=>
{
	console.log("Request for Product is made",productID,cartId,productQuantity);
	return(dispatch)=>{
		return fetch(`http://54.254.254.57:8080/hsahu/api/add-cart`,{
	method: 'post',
	body: JSON.stringify({
		"cart_id":cartId,
		"productID":productID,
		"quantity":productQuantity.toString()
	}),
	headers: new Headers({
		'Content-Type': 'application/json'
	})
}).then(response=> response.json())
		.then(json=>dispatch(recieve_product_status(json)))
	}
}
export const recieve_product_status=(productStatusRecieved)=>{
	return {type:CHECK_PRODUCT_STATUS,
    status:productStatusRecieved.flag,
    cartDetails: productStatusRecieved.data!=null ? productStatusRecieved.data:"Use Previous cart State"
}
}

export const SEARCHREQUESTSTART="SEARCHREQUESTSTART";

export const requestStartForSearch=()=>{
	return {
	type:SEARCHREQUESTSTART	
	}
}
export const searchrequest=(searchvalue)=>
{ console.log(searchvalue);
return (dispatch)=>{
console.log("Start of Searchrequest"+searchvalue)
dispatch(requestStartForSearch());
return fetch(`http://54.254.254.57:8080/hsahu/api/search/${searchvalue}`).then(response=>response.json()).
then(json=>dispatch(recieveSearchRequest(json)));

}
}

export const RECIEVE_SEARCH="RECIEVE_SEARCH";

export const recieveSearchRequest=(json)=>{
	console.log("Start of recieveSearchRequest");
	return {
	type:RECIEVE_SEARCH,
dataSourceAction:json.data
	}
}

export const SEARCH_LOCALLY="SEARCH_LOCALLY";
export const searchlocally=(searchlocallyValue)=>{

return{
	type:SEARCH_LOCALLY
}
}







export const SAVEUSERAFTERLOGIN="SAVEUSERAFTERLOGIN";

export function saveUserIdAfterLogin(userId){
	console.log("SAVEUSERAFTERLOGIN",userId);
	if(userId==null)
	{
		return {
		type:SAVEUSERAFTERLOGIN,
		userId
	}
	}
	else
	{
		return(dispatch)=>{
		dispatch(saveuserIdAfterLoginStep1(userId));
		return fetch(`http://54.254.254.57:8080/hsahu/api/address`).then(response=>response.json()).
		then(json=>dispatch(fetchUserAddress(json)));

	}


	}
}

const saveuserIdAfterLoginStep1=(userId)=>{
return {
		type:SAVEUSERAFTERLOGIN,
		userId
	}
}
export const FETCHADDRESS='FETCHADDRESS';
const fetchUserAddress=(address)=>{
return {
		type:FETCHADDRESS,
		address
	}
}

export const directAddressurl=()=>
{
	return(dispatch)=>{
	return fetch(`http://54.254.254.57:8080/hsahu/api/address`).then(response=>response.json()).
		then(json=>dispatch(fetchUserAddress(json)));
	}
}



export const FETCHSEARCHRESULT="FETCHSEARCHRESULT";
export const fetchSearchProduct=(searchItem)=>{
	return(dispatch,getState)=>{
		const searchingArea=getState().fetchmenuReducer.years;
		console.log("Another reducer ",searchingArea);
		dispatch({type:FETCHSEARCHRESULT,searchingArea,searchItem})
	}

}


export const REQUEST_PROFILE="REQUEST_PROFILE";
export const requestprofile=()=>{
	return {
	type:REQUEST_PROFILE	
	}	
}

export const RECEIEVE_PROFILE="RECEIEVE_PROFILE";
 
export const fetchProfile=()=>{

	return (dispatch)=>{
		dispatch(requestMenus());
		return fetch('http://54.254.254.57:8080/hsahu/api/fetch-profile',{credentials: 'same-origin',
	 method: "GET",
        headers: {
            "Accept": "application/json"
        }
    }).then(response=>response.json()).
		then(json=> dispatch(recieveFetchProfile(json)));
		
	}
	
}

export const recieveFetchProfile=(json)=>{
	

	return{
		type:RECEIEVE_PROFILE,
	data:json.data[0]
	}
	
}











export const INITIALSTATE="INITIALSTATE";

export function intialState(userName){
	console.log("inIATAL stATE",userName);
	return {
		type:INITIALSTATE,
		userId:userName
	}

}

export const SAVESTATE="SAVESTATE";

export function saveState(json){
	console.log("SAVE stATE",json);
	return {
		type:SAVESTATE,
		json
	}

}


