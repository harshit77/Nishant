
export const INCREMENT="INCREMENT";


export const Action1=(values)=>{

console.log("Inside Action1 "+values);
return {
	type:INCREMENT,
	values
}

}


export const DECREMENT="DECREMENT";


export const Action2=(values)=>{
console.log("Inside Action2 "+values);
return {
	type:DECREMENT,
	values
}

}

