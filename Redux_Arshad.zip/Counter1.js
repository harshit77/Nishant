import React from 'react';
import {Action1,Action2} from './action.js';
import {connect} from 'react-redux';
class Counter1 extends React.Component{
	constructor(props){
		super(props);
		this.handleClick=this.handleClick.bind(this);

	}
	handleClick(actionType,event)
	{ const{dispatch}=this.props;
		const value=parseInt(document.getElementById("value").textContent);
	console.log("Value After Click"+value);
if(actionType===1)
{	this.props.dispatch(Action1(value));}
else
{		this.props.dispatch(Action2(value));}

}
	
	render(){

		const {first}=this.props;
		return(
			<div>
			<button onClick={this.handleClick.bind(null,1)}>+ </button>
<div id="value">{first==0 ? 0 : first.newValue}</div>
			<button onClick={this.handleClick.bind(null,2)}>-</button>
			</div>
		) 
	}
}



const mapStateToProps=(state)=>{
		console.log("Inside MapStateToProps");
	const {first}=state;
return {first};

}



export default connect(mapStateToProps)(Counter1);
