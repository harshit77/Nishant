import React from 'react';
import AppBar from 'material-ui/AppBar';

const Header = () => (
  <AppBar
    title="Modus"
  />
);

export default Header;