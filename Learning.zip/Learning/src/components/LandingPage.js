import React from 'react';
import Paper from 'material-ui/Paper';
import Subheader from 'material-ui/Subheader';
import RaisedButton from 'material-ui/RaisedButton';
import ActionExplore from 'material-ui/svg-icons/action/explore'
import Swipeable from './Swipeable';

const styles= {
	Paper:{
  height:'40%',
  width:'60%',
  marginTop:'80px',
  textAlign: 'center',
  display: 'inline-block',
  backgroundColor:'#00b63f'
},
Subheader:{
	lineHeight:'18px',
	width:'90%',
	marginBottom:'4em',
	textAlign:'center'
},
button:{
	padding:'0em 3em'
}
};


export default class LandingPage extends  React.Component
{
  constructor(props)
  {
    super(props);
    this.state={landingState:true};
    this.handleStartJourney=this.handleStartJourney.bind(this);
  
  }
  handleStartJourney()
  {
  	this.setState({landingState:false});
  }
 

  render()
  {
  	return(
  		<div className="container">
  				<div id="main">
  				{this.state.landingState===true ? 
		  			<div>
		  				<div className="brandSection">
					  		 <Paper style={styles.Paper} zDepth={3} >
					  		 	<p className="brandText">Modus</p>
					  		 	<Subheader style={styles.Subheader}>A one of a kind platform to discover, create manage blogs</Subheader>
					  		 </Paper>
		  		 		</div>
		  		 		<div>
					  		 <RaisedButton
							      target="_blank"
							      label="Start your journey"
							      labelPosition="before"
							      secondary={true}
							      buttonStyle={styles.button}
							      onTouchTap={this.handleStartJourney}
							      icon={<ActionExplore/>}
							    />
				    	</div>
				    </div>
				    :
				    <Swipeable/>
				}
				
  		 </div>
  		 </div>

  		)
  }
}