import React from 'react';
import Subheader from 'material-ui/Subheader';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import DetailedContent from './DetailedContent';
import ContentClear from 'material-ui/svg-icons/content/clear';
import ActionBookmark from 'material-ui/svg-icons/action/bookmark';
import Divider from 'material-ui/Divider';
import Avatar from 'material-ui/Avatar';
import Chip from 'material-ui/Chip';
import Header from './common/Header';

import SwipeableViews from 'react-swipeable-views';

const styles = {
  slide: {
    padding: 15,
    height:'auto',
    color: '#fff',
     background: '#fff'
  }
};

const dataSet=[
{
heading:'Solo Travel Moments That Left Me Scared Shitless',
entireText:'Every once in a while, I look back at my travels and think of the moments that have changed something in me.',
img:'https://theshootingstar.files.wordpress.com/2016/09/img_0264-1.jpg?w=840',
id:1,
bookmark:10,
fullText:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
rooms:'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose ',
conclusion:'The hotel is a paradise on its own with an abundance of sights and activities for adventurous tourists'
},
{
heading:'Would You Fancy Staying In A Tea Factory?',
entireText:'In the world, there is no holiday spot where you can stay in a transformed tea factory and take part in plucking your own tea? The Heritance Tea Factory provides this treat.',
img:'http://www.romancingtheplanet.com/wp-content/uploads/Heritance-Tea-Factory-Exterior.jpg',
id:2,
bookmark:20,
fullText:'In the world, there is no holiday spot where you can stay in a transformed tea factory and take part in plucking your own tea? The Heritance Tea Factory provides this treat. Set at 2 kilometers above sea level, unforgettable views of the lush green organic plantations when the sun blends with the mist cane be seen. Guests can enjoy them as they consume tea on their terrace or at the delicious tea-themed restaurant.',
rooms:'The hotel has the best accommodation in Nuwara Eliya. It has 54 comfy rooms on four floors which were converted from withering lofts.The full-length window which once helped control temperature for the drying leaves now ensures that the hotel rooms are inundated with natural light, at the same time, offering spectacular views of the tea plantations.A key element in the rooms is wood. The doors, cupboards and shelves are still in their natural colors. Free bottles of water (Hethersett) come from a spring and is pure & natural. All rooms are also supplied with tea leaves from their own plantation. The furnishings are all locally made, from the prints displaying local villagers exchanging goods to the custom-made toiletries.The fourth floor of this hotel is a non-smoking floor.All the rooms are accessible to wheelchairs and they offer driver quarters when a guest already has their own driver. They also offer free Wi-Fi in all rooms, as well as 24-hr room service and laundry service.Babies in the hotel can receive free cots and children can receive an extra bed on request.',
conclusion:'The hotel is a paradise on its own with an abundance of sights and activities for adventurous tourists'
},
]

export default class Swipeable extends  React.Component
{
  constructor(props)
  {
    super(props);
    this. state = {open: false,active:null};
  this.handleOpen=this.handleOpen.bind(this);
  this.handleClose=this.handleClose.bind(this);
  }
  handleOpen(e){
    console.log("Fdf",e.currentTarget.dataset.id);
    this.setState({open: true,active:e.currentTarget.dataset.id});
  };

  handleClose(){
    this.setState({open: false});
  };


  render()
  {
    const actions =[
      <FlatButton
        primary={true}
        onTouchTap={this.handleClose}
        icon={<ContentClear />}
      />];
    return(
  <div>
<Header/>
  <SwipeableViews axis="y" enableMouseEvents={true} style={{height:'auto',marginTop:0}} animateHeight={true}>
    
{dataSet.map((element,index)=>{
  return (

          <div style={styles.slide} key={index}>
          <div className="displaySection">
             <img src={element.img} width="100%" height='280px'/>
               <p className="theme"> Travel </p>
            <h2 className="h2">{element.heading}</h2>
             <Subheader style={{lineHeight:'22px',margin:'1em 0',paddingLeft:0}}><label className="subheader_Label">19, Sept</label><label className="subheader_Label">6 min read </label><label className="subheader_Label">20 readers</label></Subheader>
             <p  className="p">{element.entireText}</p>
              <FlatButton label="Read More ..." primary={true} data-id={element.id} onTouchTap={this.handleOpen} />
             <div className="bookmarks">
              <FlatButton label={`${element.bookmark} bookmarks`} labelPosition="after" secondary={true} icon={<ActionBookmark />} />
             </div>
         </div>
         <Divider />
        <div className="otherSection">
         <Chip>
          <Avatar src="http://2.gravatar.com/avatar/b6b8995609f7d861cbba00a6ae233516?s=128&r=g" />
          ShahRukh Khan
        </Chip>
        </div>
   </div>
        )

})
}
  </SwipeableViews>

   <Dialog
          title="Read More..."
          actions={actions}
          modal={false}
          contentStyle={{position:'fixed',top:0,width:'100%',height:document.documentElement.clientHeight}}
          actionsContainerStyle={{position:'fixed',top:0,paddingTop:20}}
          open={this.state.open}
          onRequestClose={this.handleClose}
          autoScrollBodyContent={true}
          bodyStyle={{top:0,left:0,minHeight:document.documentElement.clientHeight-120,overflowY:'scroll'}}
        >
         <DetailedContent dataSet={dataSet} active={this.state.active}/>
        </Dialog>
  </div>
  )

}

}



