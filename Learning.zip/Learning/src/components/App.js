import React from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import LandingPage from './LandingPage';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();
require('./../../dist/stylus/style.styl');

export default class App extends React.Component
{
	constructor(props)
	{
		super(props);
	}

	render()
	{
		return(
			<div>
			
			<MuiThemeProvider>
			<LandingPage/>
			</MuiThemeProvider>
			</div>

			)
	}
}