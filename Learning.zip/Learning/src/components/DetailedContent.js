import React from 'react';
import Subheader from 'material-ui/Subheader'; 
const styles={
	subheader:{lineHeight:'22px',margin:'1em 0',paddingLeft:0,fontSize:'2em'}
}

export default class DetailedContent extends  React.Component
{
	constructor(props)
	{
		super(props);
	}

	render()
	{console.log(this.props.dataSet,this.props.active);

		return(
			<div>
				<img src={this.props.dataSet[this.props.active-1].img} width="100%" height="280px"/>
    		 	 <h2 className="h2">{this.props.dataSet[this.props.active-1].heading}</h2>
  			  	 <Subheader style={{lineHeight:'22px',margin:'1em 0',paddingLeft:0}}><label className="subheader_Label">19, Sept</label><label className="subheader_Label">6 min read </label><label className="subheader_Label">20 readers</label></Subheader>
				 <p  className="p">{this.props.dataSet[this.props.active-1].fullText}.</p>


				 <Subheader style={styles.subheader}>Rooms</Subheader>
				  <p  className="p">{this.props.dataSet[this.props.active-1].rooms}.</p>


				  <Subheader style={styles.subheader}>Conclusion</Subheader>
				  <p  className="p">{this.props.dataSet[this.props.active-1].conclusion}.</p>
				
			 </div>
			)

	}
}