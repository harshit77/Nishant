var HtmlWebpackPlugin=require('html-webpack-plugin');
var ExtractTextPlugin=require('extract-text-webpack-plugin');
var webpack=require('webpack');
var path=require("path");
var isProd=process.env.NODE_ENV==="production";
var cssDEV=['style-loader','css-loader','stylus-loader'];
var cssProd=ExtractTextPlugin.extract({
		use:['css-loader','stylus-loader'],
		fallback:"style-loader"

	});

module.exports={
	context: path.resolve(process.cwd(), './src'),
entry:['react-hot-loader/patch',
    // activate HMR for React

    'webpack-dev-server/client?http://localhost:8080',
    // bundle the client for webpack-dev-server
    // and connect to the provided endpoint

    'webpack/hot/only-dev-server',
    './index.js'],

output:{
	path:path.resolve(__dirname,"dist"),
	filename:"app.bundle.js"
},
module:{
rules:[{
	test:/\.js$/,
	use:"babel-loader",
	exclude:/node_modules/
},
{
	test:/\.styl$/,
	use:isProd ? cssProd:cssDEV
}
]

},
devServer:{
hot:true,
contentBase:path.resolve(__dirname,"dist"),
compress:true,
historyApiFallback: true
},
plugins:[new HtmlWebpackPlugin({
	title:"Modus",
	filename:"index.html",
	template:"indexTemplate.html",
	hash:true,
	minify:{
		collapseWhitespace:true
	}
}),
new ExtractTextPlugin({
filename:"style.css",
disable:!isProd,
allChunks:true
}),new webpack.HotModuleReplacementPlugin(),
    // enable HMR globally

    new webpack.NamedModulesPlugin(),
]

}