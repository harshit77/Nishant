export const TABLE_COLUMNS={
    'flight_number':'No:',
    'launch_date_utc':'Launched (UTC)',
    'site_name':'Location',
    'mission_name':'Mission',
    'orbit':'Orbit',
    'launch_success':'Launch Status',
    'rocket_name':'Rocket'
}

export const SPACEINFOLIST={
    'flight_number':'Flight Number',
    'mission_name':'Mission Name',
    'rocket_type':'Rocket Type',
    'rocket_name':'Rocket Name',
    'manufacturer':'Manufacturer',
    'nationality':'Nationality',
    'launch_date_utc':'Launch Date',
    'payload_type':'Payload Type',
    'orbit':'Orbit',
    'site_name':'Launch Site'
}

export const LAUNCH_FILTER=[
    { id: 1, text: `All Launches`,selected: true, param:'' },
    { id: 2, text: `Upcoming Launches`,selected: false, param:'upcoming' },
    { id: 3, text: `Successful Launches`,selected: false, param: 'launch_success=true' },
    { id: 4, text: `Failed Launches`,selected: false, param: 'launch_success=false'}
];

export const DATE_TIME_FILTER=[
    { id: 1, text: `Last Week`,selected: false,month: 0},
    { id: 2, text: `Last Month`,selected: false,month: 1 },
    { id: 3, text: `Last 3 Months`,selected: false,month: 3},
    { id: 4, text:`Last 6 Months`,selected: true,month: 6},
    { id: 5, text: `Last year`,selected: false,month: 12 },
    { id: 6, text:`Last 2 Year`,selected: false,month: 24}
];

export const DATE_TIME='launch_date_utc';

export const TO= " to ";

export const ITEM_PER_PAGE=10;

export const NOT_FOUND="No results found for the specified filter";

export const WIKIPEDIA="wikipedia";

export const UPCOMING="Upcoming";

export const SUCCESS="Success";

export const FAILED="Failed";

export const NOT_SPECIFIED="Not Specified";

export const LOADER="/images/Loader.jpg"; 

export const TRAILING_ICON='/images/filter.jpg';

export const LEADING_ICON='/images/chevron-down.jpg';

export const CLOSE_ICON='/images/close.jpg';

export const NASA='/images/nasa.jpg';

export const WIKIPEDIAIMG='/images/wikipedia.jpg';

export const YOUTUBE='/images/youtube.jpg';

export const CHEVRON_RIGHT_ICON='/images/chevron-right.jpg';

export const CHEVRON_LEFT_ICON='/images/chevron-left.jpg';



