export const findAllByKey=(obj, keyToFind)=> {
    return Object.entries(obj)
      .reduce((acc, [key, value]) => (key === keyToFind)
        ? acc.concat(value)
        : (typeof value === 'object' && (value!=null || value!=undefined))
        ? acc.concat(findAllByKey(value, keyToFind))
        : acc
      , [])
  };




export const clickOutside=(node)=> {
  
    const handleClick = event => {
      if (node && !node.contains(event.target)) {
        node.dispatchEvent(
          new CustomEvent('click_outside', node)
        )
      }
    }
  
      document.addEventListener('click', handleClick, true);
    
    return {
      destroy() {
        document.removeEventListener('click', handleClick, true);
      }
      }
  }


export const convertDate=(str)=> {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }



export const getDaysInMonth = (year, month) => new Date(year, month, 0).getDate()

export  const getMonths = (input, months) => {
    const date = new Date(input)
    date.setDate(1)
    date.setMonth(date.getMonth() + months)
    date.setDate(Math.min(input.getDate(), getDaysInMonth(date.getFullYear(), date.getMonth()+1)))
    return date
    }