import { writable } from 'svelte/store';

export const urlGenerator= writable({startDate:null,endDate:null,sortType:null});


export const Initial=(startDate,endDate,sortType)=>{
    urlGenerator.set({startDate,endDate,sortType})
}

export const sortFilter=(sortType)=>{
    urlGenerator.update({sortType})
}

export const calenderFilter=(startDate,endDate)=>{
    urlGenerator.update({startDate,endDate})
}

const store=()=>{
    const state={
        startDate:undefined,
        endDate:undefined,
        param:undefined,
        page:undefined
    }
    const {subscribe, set, update}= writable(state);
    const method={
            init(startDate,endDate,param) {
                    set({startDate,endDate,param,page:0})
            },

            calenderFilter(startDate,endDate) {
                update(state=> Object.assign({},state,{startDate,endDate,page:0}));
            },

            launchStatusFilter(param) {
                update(state=> Object.assign({},state,{param,page:0}));
            },

            pagination(page) {
                update(state=> Object.assign({},state,{page:page-1}));
            }

    }

    return {
        subscribe,
        ...method
    }

}

export const spaceXStore=store();