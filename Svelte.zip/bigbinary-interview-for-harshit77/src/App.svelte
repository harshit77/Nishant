<script>
	import { spaceXStore } from './store';
	import Pagination from './components/pagination.svelte';
	import Header from './containers/header.svelte';
	import SpaceTable from './containers/spaceTable.svelte';
	
</script>
<Header/>

<div class="container">
	<SpaceTable/>
	<Pagination currentPage={$spaceXStore.page+1}/>
</div>
