<style>
    .navbar-sticky-top {
    position: sticky;
    position: -webkit-sticky;
    top: 0;
    background: white;
    display: flex;
    z-index: 1;
    justify-content: center;
    align-items: center;
    min-height: 72px;
    box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
}
.logo {
    background: url(../Logo.jpg) center no-repeat;
    width: 100%;
    height: 40px;
}

</style>
<header class="navbar-sticky-top">
    <div class="logo"/>
</header>