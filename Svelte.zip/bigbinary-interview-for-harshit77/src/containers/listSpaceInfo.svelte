<script>
    import { SPACEINFOLIST, DATE_TIME } from '../constants';
    import List from '../components/list.svelte';
    import { findAllByKey } from '../helper';
    export let info;
     let listInfo= Object.keys(SPACEINFOLIST).map((keysToBeSearch,index)=> {
        return  {[keysToBeSearch]:([keysToBeSearch]== DATE_TIME ? new Date(findAllByKey(info,keysToBeSearch)[0]).toUTCString():findAllByKey(info,keysToBeSearch)[0])}
     });
</script>

<List {listInfo}/>