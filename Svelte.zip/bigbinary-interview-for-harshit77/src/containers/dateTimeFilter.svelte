<script>
    import SDateRangePicker from 's-date-range-picker';
    import { createEventDispatcher } from 'svelte';
    import { getDaysInMonth, getMonths } from '../helper.js';
    export let options;
    let startDate = new Date();
    let endDate = new Date();
    const dispatch= createEventDispatcher();
    

    const onApply=({ detail })=> {
        startDate = detail.startDate;
        endDate = detail.endDate;
        dispatch('dateSelected',{
            startDate,
            endDate
        })
    }

    


    const handleQuickLink=(month)=>{     
        startDate = month===0 ? new Date(new Date().getTime() - 1000 * 60 * 60 * 24 * 7): getMonths(new Date(),-month);
        endDate=new Date();
        dispatch("dateSelected",{
            startDate,
            endDate,
            custom: options.find(option=> option.month === month)
        });
  }
</script>
<style>
.dateTimeWrapper, .quickLink {
    display: flex;
    justify-content: flex-start;
    align-items: inherit;
    flex-flow: row wrap;
    padding: 15px;
}

.quickLink {
    flex-flow: column wrap;
    border-right: 1px solid #4B5563;
}

.quickLink >div {
    margin-bottom: 10px;
    cursor: pointer;
 }

 .datePickerWrapper {
    padding: 0 30px;
 }
</style>
<div class="dateTimeWrapper">
    <div class="quickLink">
        {#each options as option}
        <div on:click={(e)=>handleQuickLink(option.month)}>{option.text}</div>
        {/each}
    </div>
    <div class="datePickerWrapper">
        <SDateRangePicker {startDate} {endDate} on:apply={onApply} />
    </div>
</div>