<script>
    import { spaceXStore } from '../store';
    import { DATE_TIME , LAUNCH_FILTER , DATE_TIME_FILTER , TO , ITEM_PER_PAGE, TABLE_COLUMNS } from '../constants';
    import Dropdown from '../components/dropdown.svelte';
    import AsyncWrapper from '../components/asyncWrapper.svelte';
    import Modal from '../components/modal.svelte';
    import {findAllByKey, convertDate, getDaysInMonth, getMonths,  } from '../helper';
    import DateTimeFilter from './dateTimeFilter.svelte';
    export let trailingIcon='/images/calender.jpg';
    export let leadingIcon='/images/chevron-down.jpg';
    import SpaceDetail from './spaceDetail.svelte';
    let spaceTableHeight, showSpaceDetail,isOpen=false;
    

    let dateFilterActive=false,calender=(DATE_TIME_FILTER.find(calenderInput=>calenderInput.selected===true)).text;
    
	let launch,dateTime,url;
	$: url='https://api.spacexdata.com/v3/launches?limit='+ITEM_PER_PAGE+'&&offset='+$spaceXStore.page * ITEM_PER_PAGE+'&&start='+$spaceXStore.startDate+'&end='+$spaceXStore.endDate+`${$spaceXStore.param!=null ? '&&'+$spaceXStore.param:''}`;

	const defaultSetting=()=>{
		launch=(LAUNCH_FILTER.find(launch=> launch.selected===true)).param;
		dateTime=DATE_TIME_FILTER.find(dateTime=> dateTime.selected===true);
		let startDate =convertDate( dateTime.month===0 ? new Date(new Date().getTime() - 1000 * 60 * 60 * 24 * 7): getMonths(new Date(),-dateTime.month));
       	let endDate=convertDate(new Date());
		spaceXStore.init(startDate,endDate,launch)
	}
	defaultSetting();

     const showDateTimeFilter=()=> {
        showSpaceDetail=undefined
        isOpen=!isOpen;
        dateFilterActive=!dateFilterActive;
     }

     const handleSelectedDate=(e)=> {
            if(e.detail.custom!=undefined) {
                DATE_TIME_FILTER.forEach(calenderInput => {
                calenderInput.id === e.detail.custom.id ? calenderInput.selected=true : calenderInput.selected=false;
            });
                calender=e.detail.custom.text;
             }
            else {
                calender= convertDate(e.detail.startDate)+ TO + convertDate(e.detail.endDate)
            }
            spaceXStore.calenderFilter(convertDate(e.detail.startDate),convertDate(e.detail.endDate))
            dateFilterActive=!dateFilterActive;
            isOpen=!isOpen;
     }
     
     const handledSpaceInfoModal=(e)=>{
        showSpaceDetail=e.detail;
        dateFilterActive=false;
        isOpen=!isOpen;
     }

     const handleClose=(e)=> {
        isOpen=e.detail;
    }

</script>

<style>
 .sideBySide {
     display: flex;
     justify-content: space-between;
     align-items: flex-start;
     margin-top: 50px;
 }

 .sideBySide >div {
     flex: 1;
     cursor: pointer;
 }

</style>
{#if $spaceXStore.startDate!=undefined}
<div class="sideBySide">
    <div on:click={()=>showDateTimeFilter()}>
    <span class="padding-10">
        <img src={trailingIcon} alt="calender"/></span>
       {calender}
        <span class="padding-10">
            <img src={leadingIcon} alt="chevron-down"/>
        </span>
    </div>
    <div>
        <Dropdown options={LAUNCH_FILTER}/>
    </div>
</div>
{#if dateFilterActive}
<Modal {isOpen} on:close={handleClose}>
    <div slot="content">
       <DateTimeFilter options={DATE_TIME_FILTER} on:dateSelected={(e)=>handleSelectedDate(e)}/>
      </div>
</Modal>
{/if}
<table class="spaceTable">
    <thead>
        <tr>
            {#each Object.values(TABLE_COLUMNS) as headerColumn}
             <th>{headerColumn}</th>
            {/each}
        </tr>
    </thead>
<AsyncWrapper {url} renderedComponent="Table" on:spaceInfoModal={handledSpaceInfoModal}/>
</table>
{/if}


{#if showSpaceDetail!=undefined}
<SpaceDetail {isOpen} info={showSpaceDetail} on:close={handleClose}/>
{/if}