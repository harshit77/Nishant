<script>
    import Modal from '../components/modal.svelte';
    import { WIKIPEDIA, UPCOMING, SUCCESS, FAILED, NOT_SPECIFIED, NASA, WIKIPEDIAIMG ,YOUTUBE  } from '../constants';
    import  ListSpaceInfo from './listSpaceInfo.svelte';
    export let info;
    export let isOpen;

    const handleClose=(e)=> {
        console.log("space")
        isOpen=e.detail;
    }
</script>
<style>
    .spaceInfoWrapper{
        display: flex;
        justify-content: flex-start;
        align-items: inherit;
        flex-flow: column wrap;
        padding: 0 15px;
    }
    .spaceInfoHeader, .mediaLink {
        display: flex;
        justify-content: flex-start;
        align-items: flex-start;
        flex-flow: row wrap;
        padding: 0 15px 15px 0;
    }

    .mediaLink {
        margin-top: 12px;
    }

    .mediaLink img {
        margin-right: 5px;
        cursor: pointer;
    }

    .spaceImage {
        width: 72px;
        height: 72px;
        margin-right: 10px;
    }

    .spaceImage img {
        width:inherit;
        height: inherit;
    }

    .spaceInfo {
        margin-right: 10px;
    }

    .missionName {
        font-style: normal;
        font-weight: 500;
        font-size: 18px;
        color: #1F2937;
        line-height: 18px;
    }

    .rocketName {
        color: #374151;
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 12px;
        margin-top: 11px;
    }
    
    .spaceDescription {
        font-style: normal;
        font-weight: normal;
        font-size: 14px;
        line-height: 24px;
        color: #1F2937;
    }

    .spaceDescription a {
        text-decoration: underline;
        color: #AFB9EB;
    }
</style>
<div class="spaceDetailsWrapper">
<Modal {isOpen} on:close>
    <div slot="content">
        <div class="spaceInfoWrapper">
            <div class="spaceInfoHeader">
                <div class="spaceImage">
                    <img src={info.links.mission_patch_small} alt={info.mission_name}/>
                </div>
                <div class="spaceInfo">
                    <div class="missionName">{info.mission_name}</div>
                    <div class="rocketName">{info.rocket.rocket_name}</div>
                    <div class="mediaLink">
                        <img src={NASA} alt="Nasa"/>
                        <img src={WIKIPEDIAIMG} alt="wikipedia"/>
                        <img src={YOUTUBE} alt="Youtube"/>
                    </div>
                </div>
                <div class="spaceStatus">
                    {#if info.upcoming === true}
                        <div class="upcoming">{UPCOMING}</div>
                    {:else if info.launch_success === true}
                        <div class="success">{SUCCESS}</div>
                    {:else if info.launch_success === false}
                        <div class="fail">{FAILED}</div>
                    {:else if info.launch_success === null}
                    <div class="upcoming">{NOT_SPECIFIED}</div>
                    {/if}
                </div>
            </div>
            <div class="spaceDescription"> 
                {info.details} <a href={info.links.wikipedia}>{WIKIPEDIA}</a>
            </div>
            <div class="spaceDetailList">
                <ListSpaceInfo {info}/>
            </div>
        </div>
    </div>
</Modal>
</div>