<script>
  import { CLOSE_ICON } from '../constants';
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();
  export let isOpen = true;
  const handleClose=()=> {
   dispatch('close',false);
  }
</script>
<style>
div.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    z-index: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }
.overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.4);
  }
.contentWrapper {
    z-index: 10;
    max-width: 70vw;
    border-radius: 0.3rem;
    background-color: white;
    overflow: hidden;
    padding: 15px;
  }
.content {
    min-height: 50vh;
    overflow: auto;
  }

  .dismissModal {
    display: flex;
    justify-content: flex-end;
    margin-top: 5px;
    cursor: pointer;
  }
</style>
{#if isOpen}
<div class="modal">
    <div class="overlay" />
  
    <div class="contentWrapper">
  
      <div>
        <div class="dismissModal"><img src={CLOSE_ICON} alt="close" on:click={()=>handleClose()}/></div>
        <slot name="header"/>
      </div>
  
      <div class="content">
       <slot name="content"/>
      </div>
  
      <div>
        <slot name="footer"/>
      </div>
  
    </div>
  
  </div>
  {/if}