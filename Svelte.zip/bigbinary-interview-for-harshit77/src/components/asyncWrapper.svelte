<script>
    import Error from './error.svelte';
    import Table from './table.svelte';
    import { LOADER } from '../constants';
    export let url;
    export let renderedComponent;
    const getDataFromURL= async(url)=> {
        const response= await fetch(url);
        const jsonResponse= await response.json();
        return response.ok ?  jsonResponse: ((function () { throw new Error('Something Went Wrong'); }()));
    }
  $:  promise = getDataFromURL(url);

  const calcComponent=()=>{
    renderedComponent= Table;
  }
  
  calcComponent();
</script>


{#await promise}
    <div class="loaderAlign"><img src={LOADER} alt="loading...."/></div>
{:then result}
    <svelte:component this={renderedComponent} data={result} on:spaceInfoModal/>
{:catch error}
    <Error/>
{/await}
