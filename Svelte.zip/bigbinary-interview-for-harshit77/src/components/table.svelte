<script>
    import { createEventDispatcher } from  'svelte';
    import { NOT_FOUND, TABLE_COLUMNS, DATE_TIME, ITEM_PER_PAGE, UPCOMING, SUCCESS, FAILED, NOT_SPECIFIED } from '../constants';
    import { findAllByKey } from '../helper';
    export let data;
    const dispatch = createEventDispatcher();
    let tableBody=data.map((value,index)=> {
      return Object.keys(TABLE_COLUMNS).map((keysToBeSearch,index)=> {
        return  {[keysToBeSearch]:([keysToBeSearch]== DATE_TIME ? new Date(findAllByKey(value,keysToBeSearch)[0]).toUTCString():findAllByKey(value,keysToBeSearch)[0])}
        })
     });

    const handleSpaceInfo=(id)=> {
        dispatch('spaceInfoModal',data.find(rowData=> rowData.flight_number === id))
    }

</script>

    <tbody>
        {#if tableBody.length>0}
        {#each tableBody as row}
        <tr on:click={()=>handleSpaceInfo(row[0]['flight_number'])}>
            {#each row as value,index}
            <td>
                {#if value['upcoming']===true}
                    <div class="upcoming">{UPCOMING}</div>
                {:else if value[Object.keys(TABLE_COLUMNS)[index]]=== true}
                    <div class="success">{SUCCESS}</div>
                {:else if  value[Object.keys(TABLE_COLUMNS)[index]]=== false}
                    <div class="fail">{FAILED}</div>
                {:else if value[Object.keys(TABLE_COLUMNS)[index]]=== null}
                <div class="upcoming">{NOT_SPECIFIED}</div>
                {:else}
                    {value[Object.keys(TABLE_COLUMNS)[index]]}
                {/if}
            </td>
            {/each}
        </tr>
        {/each}
        {:else}
            <div class="loaderAlign">{NOT_FOUND}</div>
        {/if}
    </tbody>
