<script>
    import { SPACEINFOLIST } from '../constants';
    export let listInfo;
</script>
<style>
 .listWrapper {
     display: flex;
     justify-content: flex-start;
     align-items: flex-start;
     flex-flow: column wrap;
     margin-top: 32px;
 }

 .list {
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
    flex-flow: row wrap;
    border-bottom: 1px solid #E4E4E7;
    width: 100%;
    padding: 10px 0;
 }

 .list:first-of-type {
     padding-top: 0;
 }

 .list:last-of-type {
    border: none;
 }
 
 .list >div {
     width: 50%;
 }
</style>
<div class="listWrapper">
    {#each listInfo as info,index}
    <div class="list">
        <div class="listKey">
           {Object.values(SPACEINFOLIST)[index]}
        </div>
        <div class="listValue">
            {info[Object.keys(SPACEINFOLIST)[index]]}
        </div>
    </div>
    {/each}
</div>