<script>
    import { spaceXStore } from '../store';
    import { onMount } from 'svelte'
    import {clickOutside} from '../helper.js';
    import {  TRAILING_ICON ,LEADING_ICON } from '../constants';
    export let optionSelectedId=1;
	export let options = [
		{ id: 1, text: `All Launches`,selected:true },
		{ id: 2, text: `Upcoming Launches`,selected:false },
		{ id: 3, text: `Successful Launches`,selected:false },
        {id:4,text:`Failed Launches`,selected:false}
	];
    let dropdownText;
    let active=false;

	const handleDropdownSelection=(id)=> {
        manageOptions(id);
        options=options;
	}
    const manageOptions=(id)=>{
        options.forEach((option,index)=> option.id === id ? option.selected=true: option.selected=false);
        let selectedOption=options.find((optionToSearch)=> (optionToSearch.id === id));
        dropdownText=selectedOption.text;
        spaceXStore.launchStatusFilter(selectedOption.param)
    }
    
    const handleClickOutside=(event)=> {
        active= !active ? active: !active;
	}
    onMount(()=>{
        manageOptions(optionSelectedId);
    })

</script>

<style>
.dropdownContainer {
    position: relative;
}

.listContainer {
    position: absolute;
    top: 30px;
    background: #FFFFFF;
    z-index: 1;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    border-radius: 6px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 4px 0;
    display: none;
}

.listContainer.open {
    display: block;
}

.listItem {
    padding: 8px 16px;
    font-size: 14px;
    color: #1F2937;
    width: 100%;
    cursor: pointer;
}

.listItem.selected {
    background:#F4F5F7
}
</style>

<div class="dropdownContainer">
    <div use:clickOutside on:click_outside={handleClickOutside} on:click={()=> active=!active}>
        <span class="padding-10">
        <img src={TRAILING_ICON} alt={TRAILING_ICON}/></span>
        {dropdownText}
        <span class="padding-10">
            <img src={LEADING_ICON} alt={LEADING_ICON}/>
        </span>
    </div>
<div class={`listContainer ${active ? 'open':''}`}>
    {#each options as option}
    <div class={`listItem ${option.selected ? 'selected':''} `} on:click={handleDropdownSelection(option.id)}><div class="item">{option.text}</div> </div>
    {/each}
</div>
</div>