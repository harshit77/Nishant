<script>
    import { spaceXStore } from '../store';
    import { CHEVRON_RIGHT_ICON, CHEVRON_LEFT_ICON } from '../constants';
    export let currentPage=1;
    let initialDisplayCount=2;
    let lastPageDisplay=10;

    const range=(pageFrom, startAt)=> {
        return Array(initialDisplayCount).fill().map((_, i) => startAt+i);
    }

    const handlePagination=(updatedNumber)=>{
        spaceXStore.pagination(updatedNumber);
    }
</script>

<style>
.paginationContainer {
    display: flex;
    justify-content: flex-end;
    align-items: flex-start;
    flex-flow: row nowrap;
}
.spacePagination{
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
    flex-flow: row nowrap;
    width: auto;
    border-radius: .25em;
    border: 1px solid #e6e6e6;
}

.spacePagination li {
    margin: 0;
    list-style: none;
    flex: 0 1;
    border-right: 1px solid #e6e6e6;
}

.spacePagination div, .spacePagination span {
    float: left;
    border-radius: 0;
    padding: 10px;
    border: none;
    font-size: 12px;
    font-weight: 500;
    line-height: 16px;
}

.spacePagination .current {
    background-color: #64a281;
    border-color: #64a281;
    color: #fff;
    pointer-events: none;
}

.spacePagination .disabled {
    opacity: 0.2;
    pointer-events: none;
}
</style>

<nav role="navigation" class="paginationContainer">
    <ul class="spacePagination">
        <!-- svelte-ignore a11y-missing-attribute -->
        <li><div class:disabled={currentPage-1===0} on:click={(e)=>handlePagination(currentPage-1)}><img src={CHEVRON_LEFT_ICON} alt={CHEVRON_LEFT_ICON}/></div></li>
        {#each range(initialDisplayCount,currentPage) as page,index }
            <li><div class:current={index===0} on:click={(e)=>handlePagination(page)}>{page}</div></li>
        {/each}
        <li><span>...</span></li>
        <li><div on:click={(e)=>handlePagination(lastPageDisplay-initialDisplayCount+1+currentPage)}>{lastPageDisplay-initialDisplayCount+1+currentPage}</div></li>
        <li><div on:click={(e)=>handlePagination(currentPage+1)}><img src={CHEVRON_RIGHT_ICON} alt={CHEVRON_RIGHT_ICON}/></div></li>
    </ul>
</nav>
